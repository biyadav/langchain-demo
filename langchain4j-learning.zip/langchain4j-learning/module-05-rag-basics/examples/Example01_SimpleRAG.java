package module05.examples;

import dev.langchain4j.data.document.Document;
import dev.langchain4j.data.document.DocumentSplitter;
import dev.langchain4j.data.document.splitter.DocumentSplitters;
import dev.langchain4j.data.embedding.Embedding;
import dev.langchain4j.data.segment.TextSegment;
import dev.langchain4j.model.chat.ChatLanguageModel;
import dev.langchain4j.model.embedding.EmbeddingModel;
import dev.langchain4j.model.embedding.onnx.allminilml6v2.AllMiniLmL6V2EmbeddingModel;
import dev.langchain4j.model.openai.OpenAiChatModel;
import dev.langchain4j.store.embedding.EmbeddingMatch;
import dev.langchain4j.store.embedding.EmbeddingStore;
import dev.langchain4j.store.embedding.inmemory.InMemoryEmbeddingStore;

import java.util.List;

/**
 * Example 1: Simple RAG (Retrieval Augmented Generation)
 * 
 * ============================================================================
 * THEORY: What is RAG?
 * ============================================================================
 * 
 * RAG = Retrieval Augmented Generation
 * 
 * It allows LLMs to answer questions about YOUR data without retraining!
 * 
 * THE PROBLEM:
 * 
 * User: "What is our company's vacation policy?"
 * LLM: "I don't have information about your company's policies" ❌
 * 
 * Why? Because:
 * - LLM was trained on public data (not your company docs)
 * - Training cutoff date (doesn't know recent info)
 * - Can't access your private documents
 * 
 * THE SOLUTION: RAG
 * 
 * 1. Store your documents in a searchable format
 * 2. When user asks a question:
 *    a) Find relevant parts of your documents
 *    b) Give those parts to the LLM as context
 *    c) LLM answers based on YOUR data
 * 
 * User: "What is our company's vacation policy?"
 * System: [Finds relevant policy document]
 * LLM: "According to your policy, employees get 20 days vacation..." ✅
 * 
 * ============================================================================
 * HOW RAG WORKS (Step by Step):
 * ============================================================================
 * 
 * INDEXING PHASE (done once):
 * ┌─────────────────────────────────────────────────────────────┐
 * │ 1. LOAD DOCUMENT                                            │
 * │    "Company Policy: Employees get 20 days vacation..."      │
 * │                          ↓                                  │
 * │ 2. SPLIT INTO CHUNKS                                        │
 * │    ["Chunk1: vacation policy...", "Chunk2: sick leave..."]  │
 * │                          ↓                                  │
 * │ 3. CREATE EMBEDDINGS (convert text to numbers)             │
 * │    Chunk1 → [0.23, -0.45, 0.67, ...] (vector)             │
 * │    Chunk2 → [0.12, 0.34, -0.56, ...] (vector)             │
 * │                          ↓                                  │
 * │ 4. STORE IN VECTOR DATABASE                                 │
 * │    Database now has searchable vectors                      │
 * └─────────────────────────────────────────────────────────────┘
 * 
 * QUERY PHASE (each question):
 * ┌─────────────────────────────────────────────────────────────┐
 * │ 1. USER ASKS QUESTION                                       │
 * │    "What's the vacation policy?"                            │
 * │                          ↓                                  │
 * │ 2. CONVERT QUESTION TO EMBEDDING                            │
 * │    "vacation policy" → [0.25, -0.43, 0.65, ...] (vector)   │
 * │                          ↓                                  │
 * │ 3. SEARCH FOR SIMILAR VECTORS                               │
 * │    Find chunks with similar vectors (semantic search!)      │
 * │    Result: Chunk1 about vacation (most similar)             │
 * │                          ↓                                  │
 * │ 4. CREATE PROMPT WITH CONTEXT                               │
 * │    "Based on: [Chunk1 content]                              │
 * │     Answer: What's the vacation policy?"                    │
 * │                          ↓                                  │
 * │ 5. LLM GENERATES ANSWER                                     │
 * │    "Based on the document, employees get 20 days..."        │
 * └─────────────────────────────────────────────────────────────┘
 * 
 * ============================================================================
 * KEY CONCEPTS:
 * ============================================================================
 * 
 * 1. EMBEDDINGS
 *    - Convert text to numbers (vectors)
 *    - Similar meanings → Similar vectors
 *    - "dog" and "puppy" have similar vectors
 *    - "dog" and "car" have very different vectors
 * 
 * 2. SEMANTIC SEARCH
 *    - Search by MEANING, not keywords
 *    - Question: "vacation time"
 *    - Finds: "annual leave policy" (similar meaning!)
 *    - Traditional search would miss this
 * 
 * 3. CHUNKS
 *    - Documents are split into smaller pieces
 *    - Too large: irrelevant info mixed in
 *    - Too small: not enough context
 *    - Typical: 500-1000 characters per chunk
 * 
 * 4. VECTOR STORE
 *    - Special database for vectors
 *    - Fast similarity search
 *    - Can handle millions of vectors
 * 
 * ============================================================================
 * CONCEPTS DEMONSTRATED:
 * ============================================================================
 * - Document creation
 * - Text splitting
 * - Embedding generation
 * - Vector storage
 * - Semantic search
 * - Context-based question answering
 */
public class Example01_SimpleRAG {
    
    public static void main(String[] args) {
        
        System.out.println("=" .repeat(80));
        System.out.println("SIMPLE RAG EXAMPLE");
        System.out.println("=" .repeat(80));
        System.out.println();
        
        // ====================================================================
        // STEP 1: PREPARE DOCUMENTS
        // ====================================================================
        
        System.out.println("--- STEP 1: Prepare Documents ---");
        System.out.println();
        
        // Create sample company documents
        String companyPolicyDoc = """
            Company Vacation Policy
            
            All full-time employees are entitled to 20 days of paid vacation per year.
            Part-time employees receive vacation days prorated based on hours worked.
            Vacation days must be requested at least 2 weeks in advance.
            Unused vacation days can be carried over to the next year, up to a maximum of 5 days.
            
            Sick Leave Policy
            
            Employees receive 10 days of paid sick leave per year.
            Sick leave can be used for personal illness or to care for family members.
            A doctor's note is required for absences longer than 3 consecutive days.
            
            Remote Work Policy
            
            Employees may work remotely up to 2 days per week with manager approval.
            Core hours of 10 AM to 3 PM must be maintained regardless of location.
            All remote workers must have a reliable internet connection and dedicated workspace.
            """;
        
        // Create a Document object
        Document document = Document.from(companyPolicyDoc);
        
        System.out.println("✅ Document created (" + companyPolicyDoc.length() + " characters)");
        System.out.println();
        
        // ====================================================================
        // STEP 2: SPLIT DOCUMENT INTO CHUNKS
        // ====================================================================
        
        System.out.println("--- STEP 2: Split Document into Chunks ---");
        System.out.println();
        
        // Create a splitter that breaks document into chunks
        // - maxChunkSize: 200 characters per chunk
        // - overlap: 20 characters overlap between chunks (preserves context)
        DocumentSplitter splitter = DocumentSplitters.recursive(
            200,  // max chunk size
            20    // overlap size
        );
        
        // Split the document
        List<TextSegment> segments = splitter.split(document);
        
        System.out.println("✅ Document split into " + segments.size() + " chunks");
        System.out.println();
        
        // Display the chunks
        for (int i = 0; i < segments.size(); i++) {
            System.out.println("Chunk " + (i + 1) + ":");
            System.out.println(segments.get(i).text());
            System.out.println("(" + segments.get(i).text().length() + " characters)");
            System.out.println();
        }
        
        /*
         * WHY SPLIT?
         * 
         * 1. LLMs have context limits (can't send entire library)
         * 2. Smaller chunks = more precise retrieval
         * 3. Faster search
         * 4. Better relevance scoring
         * 
         * WHY OVERLAP?
         * 
         * Prevents important info from being split across chunks.
         * 
         * Without overlap:
         * Chunk1: "...vacation days"
         * Chunk2: "can be carried..."
         * Lost context!
         * 
         * With overlap:
         * Chunk1: "...vacation days can be..."
         * Chunk2: "...vacation days can be carried..."
         * Context preserved!
         */
        
        // ====================================================================
        // STEP 3: CREATE EMBEDDINGS
        // ====================================================================
        
        System.out.println("--- STEP 3: Create Embeddings ---");
        System.out.println();
        
        // Create embedding model (converts text to vectors)
        // Using local model (free, no API key needed!)
        EmbeddingModel embeddingModel = new AllMiniLmL6V2EmbeddingModel();
        
        System.out.println("✅ Embedding model loaded (all-MiniLM-L6-v2)");
        System.out.println("   - Runs locally");
        System.out.println("   - No API costs");
        System.out.println("   - 384-dimensional vectors");
        System.out.println();
        
        // Create embeddings for all chunks
        System.out.println("Creating embeddings for " + segments.size() + " chunks...");
        
        List<Embedding> embeddings = embeddingModel.embedAll(segments).content();
        
        System.out.println("✅ Created " + embeddings.size() + " embeddings");
        System.out.println();
        
        // Show what an embedding looks like
        System.out.println("Example embedding (first 10 dimensions):");
        float[] vector = embeddings.get(0).vector();
        System.out.print("[");
        for (int i = 0; i < 10; i++) {
            System.out.printf("%.3f", vector[i]);
            if (i < 9) System.out.print(", ");
        }
        System.out.println(", ...]");
        System.out.println("(Total dimensions: " + vector.length + ")");
        System.out.println();
        
        /*
         * WHAT ARE THESE NUMBERS?
         * 
         * Each number represents a feature of the text:
         * - Semantic meaning
         * - Topic
         * - Context
         * - Relationships
         * 
         * Similar texts have similar number patterns!
         * 
         * Example:
         * "vacation policy" → [0.23, -0.45, 0.67, ...]
         * "annual leave"    → [0.25, -0.43, 0.65, ...]  (similar!)
         * "sick leave"      → [0.18, -0.52, 0.71, ...]  (somewhat similar)
         * "remote work"     → [-0.12, 0.34, -0.23, ...] (different)
         */
        
        // ====================================================================
        // STEP 4: STORE IN VECTOR DATABASE
        // ====================================================================
        
        System.out.println("--- STEP 4: Store in Vector Database ---");
        System.out.println();
        
        // Create in-memory vector store (for demo purposes)
        EmbeddingStore<TextSegment> embeddingStore = new InMemoryEmbeddingStore<>();
        
        // Add all chunks with their embeddings
        embeddingStore.addAll(embeddings, segments);
        
        System.out.println("✅ Stored " + segments.size() + " chunks in vector database");
        System.out.println("   Ready for semantic search!");
        System.out.println();
        
        /*
         * VECTOR STORE OPTIONS:
         * 
         * IN-MEMORY (this example):
         * ✅ Fast
         * ✅ Simple
         * ❌ Lost on restart
         * ❌ Limited by RAM
         * Use for: Testing, demos
         * 
         * PERSISTENT (production):
         * - Pinecone (cloud, managed)
         * - Weaviate (self-hosted or cloud)
         * - Chroma (local, file-based)
         * - Milvus (enterprise, scalable)
         * - PostgreSQL with pgvector (if you already use Postgres)
         */
        
        // ====================================================================
        // STEP 5: QUERY THE SYSTEM
        // ====================================================================
        
        System.out.println("=" .repeat(80));
        System.out.println("QUERYING THE RAG SYSTEM");
        System.out.println("=" .repeat(80));
        System.out.println();
        
        // Create chat model for generating answers
        ChatLanguageModel chatModel = OpenAiChatModel.builder()
            .apiKey(System.getenv("OPENAI_API_KEY"))
            .modelName("gpt-4o-mini")
            .build();
        
        // Test questions
        String[] questions = {
            "How many vacation days do employees get?",
            "Can I work from home?",
            "What do I need to do if I'm sick for more than 3 days?",
            "Can I carry over unused vacation days?"
        };
        
        for (String question : questions) {
            System.out.println("--- Question ---");
            System.out.println(question);
            System.out.println();
            
            // STEP 5a: Convert question to embedding
            Embedding questionEmbedding = embeddingModel.embed(question).content();
            
            // STEP 5b: Find most relevant chunks (semantic search!)
            int maxResults = 2;  // Get top 2 most relevant chunks
            double minScore = 0.5;  // Minimum similarity score (0-1)
            
            List<EmbeddingMatch<TextSegment>> relevantChunks = 
                embeddingStore.findRelevant(questionEmbedding, maxResults, minScore);
            
            System.out.println("Found " + relevantChunks.size() + " relevant chunks:");
            for (int i = 0; i < relevantChunks.size(); i++) {
                EmbeddingMatch<TextSegment> match = relevantChunks.get(i);
                System.out.println("\nChunk " + (i + 1) + " (similarity: " + 
                    String.format("%.2f", match.score()) + "):");
                System.out.println(match.embedded().text());
            }
            System.out.println();
            
            // STEP 5c: Build prompt with context
            StringBuilder contextBuilder = new StringBuilder();
            contextBuilder.append("Answer the question based on the following context:\n\n");
            contextBuilder.append("CONTEXT:\n");
            for (EmbeddingMatch<TextSegment> match : relevantChunks) {
                contextBuilder.append(match.embedded().text()).append("\n\n");
            }
            contextBuilder.append("QUESTION: ").append(question).append("\n\n");
            contextBuilder.append("ANSWER:");
            
            String promptWithContext = contextBuilder.toString();
            
            // STEP 5d: Get answer from LLM
            String answer = chatModel.generate(promptWithContext);
            
            System.out.println("--- Answer ---");
            System.out.println(answer);
            System.out.println();
            System.out.println("=" .repeat(80));
            System.out.println();
        }
        
        /*
         * ====================================================================
         * WHAT JUST HAPPENED?
         * ====================================================================
         * 
         * For each question:
         * 
         * 1. QUESTION EMBEDDING
         *    "How many vacation days?" → [0.24, -0.42, ...]
         * 
         * 2. SEMANTIC SEARCH
         *    Compare question embedding to all chunk embeddings
         *    Find most similar (using cosine similarity)
         * 
         * 3. RETRIEVE RELEVANT CHUNKS
         *    Get the top N most relevant chunks
         *    Each has a similarity score (0-1)
         * 
         * 4. BUILD PROMPT
         *    Context: [relevant chunks]
         *    Question: [user question]
         * 
         * 5. LLM GENERATES ANSWER
         *    Based on provided context
         *    Cites information from documents
         * 
         * ====================================================================
         * ADVANTAGES OF RAG:
         * ====================================================================
         * 
         * ✅ UP-TO-DATE INFORMATION
         *    Add new documents anytime - no retraining
         * 
         * ✅ YOUR PRIVATE DATA
         *    Works with company docs, personal notes, anything
         * 
         * ✅ ACCURATE & GROUNDED
         *    Answers based on actual documents (less hallucination)
         * 
         * ✅ CITED SOURCES
         *    Can show which document was used
         * 
         * ✅ COST EFFECTIVE
         *    No model retraining needed
         * 
         * ✅ DYNAMIC
         *    Update documents, results change immediately
         * 
         * ====================================================================
         * LIMITATIONS & CHALLENGES:
         * ====================================================================
         * 
         * ⚠️ QUALITY DEPENDS ON DOCUMENTS
         *    Bad documents → Bad answers
         * 
         * ⚠️ RETRIEVAL ACCURACY
         *    Must find right chunks
         *    May miss relevant info
         * 
         * ⚠️ CHUNK SIZE TRADEOFF
         *    Too small: No context
         *    Too large: Too much noise
         * 
         * ⚠️ COMPUTATIONAL COST
         *    Embedding creation takes time
         *    Vector search has overhead
         */
    }
    
    /**
     * Helper: Demonstrate how semantic search works
     */
    public static void demonstrateSemanticSearch() {
        System.out.println("=" .repeat(80));
        System.out.println("SEMANTIC SEARCH vs KEYWORD SEARCH");
        System.out.println("=" .repeat(80));
        System.out.println();
        
        EmbeddingModel model = new AllMiniLmL6V2EmbeddingModel();
        
        String[] texts = {
            "I love programming in Java",
            "Coding in Java is fun",
            "The weather is nice today",
            "Python is a great language"
        };
        
        String query = "java development";
        
        System.out.println("Query: \"" + query + "\"");
        System.out.println();
        
        // Create embeddings
        Embedding queryEmbedding = model.embed(query).content();
        
        // Calculate similarity with each text
        for (String text : texts) {
            Embedding textEmbedding = model.embed(text).content();
            
            // Cosine similarity (how similar the vectors are)
            double similarity = cosineSimilarity(
                queryEmbedding.vector(),
                textEmbedding.vector()
            );
            
            System.out.printf("Text: \"%s\"%n", text);
            System.out.printf("Similarity: %.4f%n", similarity);
            System.out.println();
        }
        
        /*
         * RESULTS WILL SHOW:
         * 
         * "I love programming in Java" → HIGH similarity
         * "Coding in Java is fun" → HIGH similarity
         * "Python is a great language" → MEDIUM similarity (still about programming)
         * "The weather is nice today" → LOW similarity
         * 
         * KEYWORD SEARCH would only find texts with "java" or "development"
         * SEMANTIC SEARCH finds texts about the CONCEPT, even without exact words!
         */
    }
    
    /**
     * Calculate cosine similarity between two vectors
     */
    private static double cosineSimilarity(float[] vectorA, float[] vectorB) {
        double dotProduct = 0.0;
        double normA = 0.0;
        double normB = 0.0;
        
        for (int i = 0; i < vectorA.length; i++) {
            dotProduct += vectorA[i] * vectorB[i];
            normA += vectorA[i] * vectorA[i];
            normB += vectorB[i] * vectorB[i];
        }
        
        return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
    }
}

/*
 * ============================================================================
 * EXERCISE IDEAS:
 * ============================================================================
 * 
 * 1. BUILD YOUR OWN FAQ SYSTEM
 *    - Create documents with common questions and answers
 *    - Index them
 *    - Build a chatbot that answers questions
 * 
 * 2. DOCUMENT CHAT
 *    - Load your own text files
 *    - Ask questions about them
 *    - Compare with just reading the file
 * 
 * 3. COMPARE CHUNK SIZES
 *    - Try different chunk sizes (100, 500, 1000 characters)
 *    - Ask same questions
 *    - See which works best
 * 
 * 4. TEST SEMANTIC SEARCH
 *    - Create documents about different topics
 *    - Ask questions using synonyms (not exact words)
 *    - Verify it finds right documents
 * 
 * ============================================================================
 * NEXT STEPS:
 * ============================================================================
 * 
 * This example shows basic RAG. Next topics:
 * 
 * - Loading real PDFs, Word docs
 * - Better splitting strategies
 * - Persistent vector stores
 * - Re-ranking results
 * - Metadata filtering
 * - Hybrid search (semantic + keyword)
 * - Citation tracking
 */

