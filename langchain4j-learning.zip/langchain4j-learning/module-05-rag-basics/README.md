# Module 5: RAG Basics (Retrieval Augmented Generation)

## 🎯 Learning Goals

By the end of this module, you will:
- Understand what RAG is and why it's important
- Load and process documents
- Create embeddings
- Store and search vectors
- Build a simple Q&A system over your documents

## 📚 Theory

### What is RAG?

**RAG** = **R**etrieval **A**ugmented **G**eneration

It allows LLMs to answer questions about YOUR data without retraining the model.

### The Problem

LLMs have limitations:
- ❌ Training data cutoff (knowledge is outdated)
- ❌ Don't know your private data
- ❌ Can't access real-time information
- ❌ Hallucinate when unsure

### The Solution: RAG

```
Your Documents → Split → Embed → Store in Vector DB
                                          ↓
User Question → Embed → Search Similar → Retrieve Context
                                          ↓
Context + Question → LLM → Answer with sources
```

### How RAG Works

1. **Index Time** (Done Once):
   ```
   Document → Split into chunks → Create embeddings → Store
   ```

2. **Query Time** (Each question):
   ```
   Question → Create embedding → Find similar chunks → Send to LLM
   ```

### Key Components

#### 1. Document Loaders
Load documents from various sources:
- PDF files
- Word documents
- Text files
- Web pages
- APIs

#### 2. Text Splitters
Break documents into chunks:
- By character count
- By tokens
- By sentences
- By paragraphs

**Why split?**
- LLMs have context limits
- Smaller chunks = more precise retrieval
- Balance: too small (no context) vs too large (irrelevant info)

#### 3. Embeddings
Convert text to vectors (arrays of numbers):
- Similar text → Similar vectors
- "dog" and "puppy" are close
- "dog" and "car" are far

**Popular Models:**
- OpenAI embeddings
- all-MiniLM-L6-v2 (local, free)
- sentence-transformers

#### 4. Vector Stores
Databases optimized for similarity search:
- In-memory (for testing)
- Pinecone (cloud)
- Weaviate (self-hosted)
- Chroma (local)
- Milvus (enterprise)

### RAG Architecture

```
┌─────────────────────────────────────────────────┐
│              INDEXING PHASE                     │
├─────────────────────────────────────────────────┤
│                                                 │
│  PDF/TXT → DocumentLoader → Document           │
│                                 ↓               │
│              TextSplitter → Chunks              │
│                                 ↓               │
│              EmbeddingModel → Vectors           │
│                                 ↓               │
│              VectorStore → Indexed              │
│                                                 │
└─────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────┐
│              QUERY PHASE                        │
├─────────────────────────────────────────────────┤
│                                                 │
│  Question → EmbeddingModel → Query Vector      │
│                                 ↓               │
│              VectorStore → Similar Chunks       │
│                                 ↓               │
│              Chunks + Question → LLM            │
│                                 ↓               │
│              Answer                             │
│                                                 │
└─────────────────────────────────────────────────┘
```

### When to Use RAG

✅ **Good for:**
- Q&A over documentation
- Chat with PDFs
- Company knowledge bases
- Customer support (using FAQs/docs)
- Research assistants

❌ **Not ideal for:**
- Real-time data (use tools instead)
- Simple calculations (use tools)
- When you need guaranteed accuracy
- Very small datasets

## 💻 Examples

### Example 1: Simple Document Q&A
**File**: `Example01_SimpleRAG.java`

Basic RAG pipeline with in-memory storage.

**Concepts**:
- Loading documents
- Creating embeddings
- Storing vectors
- Querying

### Example 2: PDF Chat
**File**: `Example02_PDFChat.java`

Chat with PDF documents.

**Concepts**:
- PDF loading
- Text splitting strategies
- Conversation with context

### Example 3: Advanced Retrieval
**File**: `Example03_AdvancedRetrieval.java`

Improving retrieval quality.

**Concepts**:
- Metadata filtering
- Re-ranking
- Multiple document types

## 🎓 Key Takeaways

1. **RAG extends LLM knowledge** - Your data, AI's intelligence
2. **Embeddings enable semantic search** - Find by meaning, not keywords
3. **Chunking strategy matters** - Balance context and precision
4. **RAG is production-ready** - Used in real applications

## ✅ Exercises

### Exercise 1: Documentation Q&A
Build a system that answers questions about Java documentation.

**Requirements**:
- Load Java docs
- Split appropriately
- Answer technical questions
- Cite sources

### Exercise 2: Personal Knowledge Base
Create a searchable knowledge base from your notes.

**Requirements**:
- Load text files
- Support multiple documents
- Find relevant information
- Summarize findings

### Exercise 3: Company Policy Bot
Build a bot that answers questions about company policies.

**Requirements**:
- Load policy documents
- Handle updates
- Provide accurate answers
- Track what's being asked

## 📖 Additional Reading

- [LangChain4j RAG Docs](https://docs.langchain4j.dev/tutorials/rag)
- [Vector Database Comparison](https://github.com/langchain4j/langchain4j#vector-stores)
- [Embeddings Guide](https://platform.openai.com/docs/guides/embeddings)

## ➡️ Next Module

Continue to **Module 6: Advanced RAG** for optimization techniques!

