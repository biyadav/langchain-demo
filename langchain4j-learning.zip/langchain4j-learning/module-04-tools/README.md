# Module 4: Tools & Function Calling

## 🎯 Learning Goals

By the end of this module, you will:
- Understand what tools are and why they're powerful
- Create custom tools for your agents
- Use the @Tool annotation
- Build agents that use multiple tools
- Implement complex multi-step workflows

## 📚 Theory

### What are Tools?

Tools are functions that your AI agent can call to interact with the external world.

**Without Tools:**
```
User: "What's the weather in NYC?"
AI: "I don't have access to real-time weather data."  ❌
```

**With Tools:**
```
User: "What's the weather in NYC?"
AI: [calls weatherTool("NYC")]
AI: "It's 72°F and sunny in NYC!"  ✅
```

### How Tools Work

```
1. User asks question
2. AI decides which tool(s) to use
3. AI calls tool with parameters
4. Tool executes and returns result
5. AI uses result to formulate answer
```

This is called **Function Calling** or **Tool Use**.

### Architecture

```
User: "What's 25 * 4 in euros?"
         ↓
AI Reasoning: "I need to calculate, then convert"
         ↓
Call Tool: calculator(25, 4, "multiply")
         → Returns: 100
         ↓
Call Tool: currencyConverter(100, "USD", "EUR")
         → Returns: 92.5
         ↓
AI Response: "25 * 4 = 100 USD, which is 92.5 EUR"
```

### Types of Tools

| Category | Examples |
|----------|----------|
| **Information Retrieval** | Weather, news, database queries |
| **Calculations** | Math, unit conversion, statistics |
| **External APIs** | Web search, social media, maps |
| **System Operations** | File operations, email, scheduling |
| **Business Logic** | Order processing, inventory checks |

### Tool Design Principles

1. **Single Responsibility**: One tool, one purpose
2. **Clear Description**: AI needs to know when to use it
3. **Explicit Parameters**: Well-defined inputs
4. **Error Handling**: Graceful failures
5. **Fast Execution**: Don't block for too long

## 💻 Examples

### Example 1: Simple Calculator Tool
**File**: `Example01_SimpleCalculatorTool.java`

Basic tool creation and usage.

**Concepts**:
- @Tool annotation
- Tool description
- Parameter handling
- Tool execution

### Example 2: Multiple Tools
**File**: `Example02_MultipleTool.java`

Agent with multiple tools working together.

**Concepts**:
- Tool selection
- Multi-step workflows
- Tool chaining
- Result combination

### Example 3: External API Tool
**File**: `Example03_ExternalAPITool.java`

Calling external services from tools.

**Concepts**:
- HTTP requests in tools
- API integration
- Error handling
- Rate limiting

### Example 4: Database Tool
**File**: `Example04_DatabaseTool.java`

Tools that interact with databases.

**Concepts**:
- Database queries
- Data retrieval
- Safe SQL execution
- Result formatting

## 🎓 Key Takeaways

1. **Tools extend AI capabilities** - From knowledge to action
2. **Good descriptions are critical** - AI needs to know when to use each tool
3. **Design for composition** - Tools should work together
4. **Handle errors gracefully** - Tools can fail

## ✅ Exercises

### Exercise 1: Email Tool
Create tools for email operations.

**Requirements**:
- sendEmail(to, subject, body)
- searchEmails(query)
- markAsRead(emailId)

### Exercise 2: File System Tools
Build tools for file operations.

**Requirements**:
- listFiles(directory)
- readFile(path)
- searchInFiles(query)

### Exercise 3: E-commerce Tools
Create shopping-related tools.

**Requirements**:
- searchProducts(query)
- getProductDetails(id)
- addToCart(productId, quantity)
- checkout()

## 📖 Additional Reading

- [LangChain4j Tools Docs](https://docs.langchain4j.dev/tutorials/tools)
- [OpenAI Function Calling](https://platform.openai.com/docs/guides/function-calling)
- [Anthropic Tool Use](https://docs.anthropic.com/claude/docs/tool-use)

## ➡️ Next Module

Continue to **Module 5: RAG Basics** to learn about document retrieval!

