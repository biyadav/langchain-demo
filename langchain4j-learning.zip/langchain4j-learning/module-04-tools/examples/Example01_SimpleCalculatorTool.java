package module04.examples;

import dev.langchain4j.agent.tool.Tool;
import dev.langchain4j.model.chat.ChatLanguageModel;
import dev.langchain4j.model.openai.OpenAiChatModel;
import dev.langchain4j.service.AiServices;

/**
 * Example 1: Simple Calculator Tool
 * 
 * Tools let AI agents perform actions and calculations.
 * The AI decides when to use the tool based on the user's request.
 * 
 * Concepts:
 * - @Tool annotation
 * - Tool description
 * - Automatic tool calling
 * - Result integration
 */
public class Example01_SimpleCalculatorTool {
    
    /**
     * Tool Class
     * 
     * Methods annotated with @Tool can be called by the AI.
     * The description helps the AI understand when to use the tool.
     */
    static class CalculatorTools {
        
        @Tool("Adds two numbers")
        public double add(double a, double b) {
            System.out.println("🔧 Tool called: add(" + a + ", " + b + ")");
            return a + b;
        }
        
        @Tool("Subtracts second number from first")
        public double subtract(double a, double b) {
            System.out.println("🔧 Tool called: subtract(" + a + ", " + b + ")");
            return a - b;
        }
        
        @Tool("Multiplies two numbers")
        public double multiply(double a, double b) {
            System.out.println("🔧 Tool called: multiply(" + a + ", " + b + ")");
            return a * b;
        }
        
        @Tool("Divides first number by second")
        public double divide(double a, double b) {
            System.out.println("🔧 Tool called: divide(" + a + ", " + b + ")");
            if (b == 0) {
                throw new IllegalArgumentException("Cannot divide by zero");
            }
            return a / b;
        }
        
        @Tool("Calculates the square root of a number")
        public double squareRoot(double number) {
            System.out.println("🔧 Tool called: squareRoot(" + number + ")");
            return Math.sqrt(number);
        }
        
        @Tool("Calculates first number raised to the power of second")
        public double power(double base, double exponent) {
            System.out.println("🔧 Tool called: power(" + base + ", " + exponent + ")");
            return Math.pow(base, exponent);
        }
    }
    
    /**
     * AI Service that can use calculator tools
     */
    interface MathAssistant {
        String chat(String userMessage);
    }
    
    public static void main(String[] args) {
        
        // Create the model
        ChatLanguageModel model = OpenAiChatModel.builder()
            .apiKey(System.getenv("OPENAI_API_KEY"))
            .modelName("gpt-4o-mini")
            .temperature(0.0)  // Low temperature for precise calculations
            .build();
        
        // Create calculator tools instance
        CalculatorTools calculatorTools = new CalculatorTools();
        
        // Create AI Service WITH TOOLS
        MathAssistant assistant = AiServices.builder(MathAssistant.class)
            .chatLanguageModel(model)
            .tools(calculatorTools)  // Register the tools!
            .build();
        
        // ============================================
        // EXAMPLE 1: Simple Calculation
        // ============================================
        
        System.out.println("=== Simple Calculation ===\n");
        String question1 = "What is 157 + 284?";
        System.out.println("User: " + question1);
        String answer1 = assistant.chat(question1);
        System.out.println("AI: " + answer1 + "\n");
        
        // ============================================
        // EXAMPLE 2: Multiple Operations
        // ============================================
        
        System.out.println("=== Multiple Operations ===\n");
        String question2 = "Calculate (15 + 25) * 3";
        System.out.println("User: " + question2);
        String answer2 = assistant.chat(question2);
        System.out.println("AI: " + answer2 + "\n");
        
        // ============================================
        // EXAMPLE 3: Complex Calculation
        // ============================================
        
        System.out.println("=== Complex Calculation ===\n");
        String question3 = "What is the square root of 144, then multiply by 5?";
        System.out.println("User: " + question3);
        String answer3 = assistant.chat(question3);
        System.out.println("AI: " + answer3 + "\n");
        
        // ============================================
        // EXAMPLE 4: Word Problem
        // ============================================
        
        System.out.println("=== Word Problem ===\n");
        String question4 = """
            I have $1000. I spend $350 on rent, $150 on groceries, 
            and $75 on entertainment. How much do I have left?
            """;
        System.out.println("User: " + question4);
        String answer4 = assistant.chat(question4);
        System.out.println("AI: " + answer4 + "\n");
        
        // ============================================
        // EXAMPLE 5: No Tool Needed
        // ============================================
        
        System.out.println("=== No Tool Needed ===\n");
        String question5 = "What is the capital of France?";
        System.out.println("User: " + question5);
        String answer5 = assistant.chat(question5);
        System.out.println("AI: " + answer5 + "\n");
        // Notice: No tool is called - AI knows it doesn't need calculator!
        
        /*
         * HOW IT WORKS:
         * 
         * 1. User asks a question
         * 2. AI analyzes: "Do I need tools for this?"
         * 3. If yes, AI decides which tool(s) and parameters
         * 4. LangChain4j calls the Java method
         * 5. Result is sent back to AI
         * 6. AI formulates natural language response
         * 
         * KEY POINTS:
         * 
         * - AI decides when to use tools
         * - Can call multiple tools in sequence
         * - Tool results are used to answer user
         * - Tools make AI more capable
         */
    }
    
    /**
     * Example with better descriptions for complex tools
     */
    static class AdvancedMathTools {
        
        @Tool("""
            Calculates compound interest.
            Parameters:
            - principal: Initial amount
            - rate: Annual interest rate (as decimal, e.g., 0.05 for 5%)
            - time: Number of years
            - frequency: Compounds per year (e.g., 12 for monthly)
            """)
        public double compoundInterest(
                double principal,
                double rate,
                double time,
                int frequency) {
            return principal * Math.pow(
                1 + (rate / frequency),
                frequency * time
            );
        }
        
        @Tool("""
            Calculates the factorial of a number.
            Only works for integers up to 20.
            """)
        public long factorial(int n) {
            if (n < 0 || n > 20) {
                throw new IllegalArgumentException(
                    "Factorial only supports 0-20"
                );
            }
            long result = 1;
            for (int i = 2; i <= n; i++) {
                result *= i;
            }
            return result;
        }
    }
}

/*
 * BEST PRACTICES FOR TOOLS:
 * 
 * 1. CLEAR DESCRIPTIONS
 *    - Explain what the tool does
 *    - Describe parameters
 *    - Mention limitations
 *    
 * 2. GOOD NAMING
 *    - Verb-based names (calculate, get, send)
 *    - Clear parameter names
 *    
 * 3. ERROR HANDLING
 *    - Validate inputs
 *    - Throw meaningful exceptions
 *    - Handle edge cases
 *    
 * 4. PERFORMANCE
 *    - Keep tools fast
 *    - Avoid blocking operations
 *    - Consider async for slow operations
 *    
 * 5. STATELESS
 *    - Tools should be stateless when possible
 *    - Use parameters to pass context
 *    
 * EXPERIMENT:
 * - Add more mathematical operations
 * - Create unit conversion tools
 * - Build date/time tools
 * - Make a statistics calculator
 */

