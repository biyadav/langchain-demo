package module04.examples;

import dev.langchain4j.agent.tool.Tool;
import dev.langchain4j.model.chat.ChatLanguageModel;
import dev.langchain4j.model.openai.OpenAiChatModel;
import dev.langchain4j.service.AiServices;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * Example 2: Multiple Tools Working Together
 * 
 * ============================================================================
 * THEORY: Multi-Tool Agents
 * ============================================================================
 * 
 * Real-world agents need access to MULTIPLE tools to solve complex problems.
 * 
 * Single Tool Agent (Limited):
 * User: "What's 15 + 25?"
 * AI: [uses calculator] → "40"
 * 
 * Multi-Tool Agent (Powerful):
 * User: "It's 3 PM here. What time is it in Tokyo, and how many hours difference?"
 * AI: [uses time tool] → "3 PM here"
 * AI: [uses timezone tool] → "6 AM tomorrow in Tokyo"
 * AI: [uses calculator] → "15 hours difference"
 * AI: "It's 6 AM in Tokyo (next day), which is 15 hours ahead."
 * 
 * ============================================================================
 * HOW MULTI-TOOL SELECTION WORKS:
 * ============================================================================
 * 
 * 1. USER ASKS QUESTION
 *    "What's the weather in NYC and how far is it from Boston?"
 * 
 * 2. AI ANALYZES REQUIREMENTS
 *    - Needs weather data → weather tool
 *    - Needs distance → distance calculator tool
 * 
 * 3. AI DECIDES TOOL SEQUENCE
 *    Step 1: Call weatherTool("NYC")
 *    Step 2: Call distanceTool("NYC", "Boston")
 * 
 * 4. TOOLS EXECUTE
 *    weatherTool → "72°F, Sunny"
 *    distanceTool → "215 miles"
 * 
 * 5. AI SYNTHESIZES ANSWER
 *    "The weather in NYC is 72°F and sunny. 
 *     It's about 215 miles from Boston."
 * 
 * ============================================================================
 * TOOL SELECTION INTELLIGENCE:
 * ============================================================================
 * 
 * The LLM decides which tools to use based on:
 * 
 * 1. TOOL DESCRIPTIONS
 *    @Tool("Gets current weather") → AI knows when to use this
 * 
 * 2. PARAMETER NAMES & TYPES
 *    getWeather(String city) → AI knows it needs a city name
 * 
 * 3. CONTEXT
 *    User mentions "temperature" → AI thinks weather tool
 *    User mentions "calculate" → AI thinks calculator tool
 * 
 * 4. PREVIOUS RESULTS
 *    Tool result influences next tool choice
 * 
 * ============================================================================
 * CONCEPTS DEMONSTRATED:
 * ============================================================================
 * - Multiple tool classes
 * - Tool coordination
 * - Sequential tool calling
 * - Result combination
 * - Tool selection logic
 */
public class Example02_MultipleTools {
    
    // ========================================================================
    // TOOL CLASS 1: Time & Date Tools
    // ========================================================================
    
    /**
     * Tools for getting current time and date information
     * 
     * WHY SEPARATE CLASS?
     * - Logical grouping
     * - Easy to test
     * - Reusable across agents
     */
    static class TimeTools {
        
        @Tool("Gets the current time in HH:MM:SS format")
        public String getCurrentTime() {
            String time = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"));
            System.out.println("🔧 Tool called: getCurrentTime() → " + time);
            return time;
        }
        
        @Tool("Gets the current date in YYYY-MM-DD format")
        public String getCurrentDate() {
            String date = LocalDate.now().toString();
            System.out.println("🔧 Tool called: getCurrentDate() → " + date);
            return date;
        }
        
        @Tool("Gets the day of the week (Monday, Tuesday, etc.)")
        public String getDayOfWeek() {
            String day = LocalDate.now().getDayOfWeek().toString();
            System.out.println("🔧 Tool called: getDayOfWeek() → " + day);
            return day;
        }
        
        @Tool("""
            Calculates the number of days between two dates.
            Dates must be in YYYY-MM-DD format.
            """)
        public long daysBetween(String date1, String date2) {
            System.out.println("🔧 Tool called: daysBetween(" + date1 + ", " + date2 + ")");
            
            LocalDate d1 = LocalDate.parse(date1);
            LocalDate d2 = LocalDate.parse(date2);
            
            long days = Math.abs(d1.toEpochDay() - d2.toEpochDay());
            System.out.println("   → Result: " + days + " days");
            return days;
        }
    }
    
    // ========================================================================
    // TOOL CLASS 2: Math & Calculation Tools
    // ========================================================================
    
    /**
     * Mathematical operations and calculations
     */
    static class MathTools {
        
        @Tool("Adds two numbers together")
        public double add(double a, double b) {
            System.out.println("🔧 Tool called: add(" + a + ", " + b + ")");
            return a + b;
        }
        
        @Tool("Subtracts second number from first")
        public double subtract(double a, double b) {
            System.out.println("🔧 Tool called: subtract(" + a + ", " + b + ")");
            return a - b;
        }
        
        @Tool("Multiplies two numbers")
        public double multiply(double a, double b) {
            System.out.println("🔧 Tool called: multiply(" + a + ", " + b + ")");
            return a * b;
        }
        
        @Tool("Divides first number by second")
        public double divide(double a, double b) {
            System.out.println("🔧 Tool called: divide(" + a + ", " + b + ")");
            if (b == 0) throw new IllegalArgumentException("Cannot divide by zero");
            return a / b;
        }
        
        @Tool("Calculates percentage: (value / total) * 100")
        public double percentage(double value, double total) {
            System.out.println("🔧 Tool called: percentage(" + value + ", " + total + ")");
            return (value / total) * 100;
        }
        
        @Tool("Calculates the average of a list of numbers")
        public double average(double[] numbers) {
            System.out.println("🔧 Tool called: average(" + Arrays.toString(numbers) + ")");
            return Arrays.stream(numbers).average().orElse(0.0);
        }
    }
    
    // ========================================================================
    // TOOL CLASS 3: Text & String Tools
    // ========================================================================
    
    /**
     * String manipulation and text processing
     */
    static class TextTools {
        
        @Tool("Counts the number of words in a text")
        public int countWords(String text) {
            System.out.println("🔧 Tool called: countWords(\"" + text + "\")");
            int count = text.trim().split("\\s+").length;
            System.out.println("   → Result: " + count + " words");
            return count;
        }
        
        @Tool("Converts text to uppercase")
        public String toUpperCase(String text) {
            System.out.println("🔧 Tool called: toUpperCase(\"" + text + "\")");
            return text.toUpperCase();
        }
        
        @Tool("Reverses a string")
        public String reverse(String text) {
            System.out.println("🔧 Tool called: reverse(\"" + text + "\")");
            return new StringBuilder(text).reverse().toString();
        }
        
        @Tool("Checks if a text contains a specific word (case-insensitive)")
        public boolean containsWord(String text, String word) {
            System.out.println("🔧 Tool called: containsWord(\"" + text + "\", \"" + word + "\")");
            return text.toLowerCase().contains(word.toLowerCase());
        }
    }
    
    // ========================================================================
    // TOOL CLASS 4: Data Storage (Simulated)
    // ========================================================================
    
    /**
     * Simple in-memory data storage (simulates a database)
     * 
     * This demonstrates how tools can maintain state
     */
    static class DataStorageTools {
        
        private final Map<String, String> storage = new HashMap<>();
        
        @Tool("""
            Stores a key-value pair in memory.
            Example: store("favoriteColor", "blue")
            """)
        public String store(String key, String value) {
            System.out.println("🔧 Tool called: store(\"" + key + "\", \"" + value + "\")");
            storage.put(key, value);
            return "Stored successfully: " + key + " = " + value;
        }
        
        @Tool("""
            Retrieves a value by key from memory.
            Returns null if key doesn't exist.
            """)
        public String retrieve(String key) {
            System.out.println("🔧 Tool called: retrieve(\"" + key + "\")");
            String value = storage.get(key);
            System.out.println("   → Result: " + value);
            return value != null ? value : "No value found for key: " + key;
        }
        
        @Tool("Lists all stored keys")
        public String listKeys() {
            System.out.println("🔧 Tool called: listKeys()");
            if (storage.isEmpty()) {
                return "No data stored yet";
            }
            return "Stored keys: " + String.join(", ", storage.keySet());
        }
        
        @Tool("Clears all stored data")
        public String clearAll() {
            System.out.println("🔧 Tool called: clearAll()");
            int count = storage.size();
            storage.clear();
            return "Cleared " + count + " items";
        }
    }
    
    // ========================================================================
    // AI SERVICE: Multi-Tool Assistant
    // ========================================================================
    
    interface MultiToolAssistant {
        String chat(String message);
    }
    
    // ========================================================================
    // MAIN EXAMPLES
    // ========================================================================
    
    public static void main(String[] args) {
        
        // Create model
        ChatLanguageModel model = OpenAiChatModel.builder()
            .apiKey(System.getenv("OPENAI_API_KEY"))
            .modelName("gpt-4o-mini")
            .temperature(0.0)  // Low temp for consistent tool use
            .build();
        
        // Create all tool instances
        TimeTools timeTools = new TimeTools();
        MathTools mathTools = new MathTools();
        TextTools textTools = new TextTools();
        DataStorageTools storageTools = new DataStorageTools();
        
        // Create AI Service with ALL tools
        MultiToolAssistant assistant = AiServices.builder(MultiToolAssistant.class)
            .chatLanguageModel(model)
            .tools(timeTools, mathTools, textTools, storageTools)  // Multiple tools!
            .build();
        
        System.out.println("=" .repeat(80));
        System.out.println("MULTI-TOOL AGENT DEMONSTRATIONS");
        System.out.println("=" .repeat(80));
        System.out.println();
        
        // ====================================================================
        // EXAMPLE 1: Single Tool Use
        // ====================================================================
        
        System.out.println("--- Example 1: Single Tool ---");
        System.out.println("User: What time is it?");
        String response1 = assistant.chat("What time is it?");
        System.out.println("AI: " + response1);
        System.out.println();
        
        // ====================================================================
        // EXAMPLE 2: Multiple Tools in Sequence
        // ====================================================================
        
        System.out.println("--- Example 2: Multiple Tools in Sequence ---");
        String question2 = "What's today's date, and what day of the week is it?";
        System.out.println("User: " + question2);
        String response2 = assistant.chat(question2);
        System.out.println("AI: " + response2);
        System.out.println("✅ Used both getCurrentDate() and getDayOfWeek()");
        System.out.println();
        
        // ====================================================================
        // EXAMPLE 3: Tool Combination (Math + Date)
        // ====================================================================
        
        System.out.println("--- Example 3: Tool Combination ---");
        String question3 = "How many days until 2025-12-31, and what percentage of 2024 is that?";
        System.out.println("User: " + question3);
        String response3 = assistant.chat(question3);
        System.out.println("AI: " + response3);
        System.out.println("✅ Combined date calculation with math!");
        System.out.println();
        
        // ====================================================================
        // EXAMPLE 4: Text Processing
        // ====================================================================
        
        System.out.println("--- Example 4: Text Processing ---");
        String question4 = "How many words are in this sentence: 'The quick brown fox jumps over the lazy dog'";
        System.out.println("User: " + question4);
        String response4 = assistant.chat(question4);
        System.out.println("AI: " + response4);
        System.out.println();
        
        // ====================================================================
        // EXAMPLE 5: Data Storage (Stateful Tools)
        // ====================================================================
        
        System.out.println("--- Example 5: Data Storage ---");
        System.out.println("User: Remember that my favorite color is blue");
        String response5a = assistant.chat("Remember that my favorite color is blue");
        System.out.println("AI: " + response5a);
        System.out.println();
        
        System.out.println("User: What's my favorite color?");
        String response5b = assistant.chat("What's my favorite color?");
        System.out.println("AI: " + response5b);
        System.out.println("✅ Tool maintained state!");
        System.out.println();
        
        // ====================================================================
        // EXAMPLE 6: Complex Multi-Step Task
        // ====================================================================
        
        System.out.println("--- Example 6: Complex Multi-Step Task ---");
        String question6 = """
            Store my name as 'Alice' and age as '28'.
            Then calculate how old I'll be in 10 years,
            and tell me what day of the week it is today.
            """;
        System.out.println("User: " + question6);
        String response6 = assistant.chat(question6);
        System.out.println("AI: " + response6);
        System.out.println("✅ Used storage, math, and date tools together!");
        System.out.println();
        
        // ====================================================================
        // EXAMPLE 7: Tool Selection Intelligence
        // ====================================================================
        
        System.out.println("--- Example 7: Intelligent Tool Selection ---");
        System.out.println("User: Is the word 'quick' in 'The quick brown fox'?");
        String response7 = assistant.chat("Is the word 'quick' in 'The quick brown fox'?");
        System.out.println("AI: " + response7);
        System.out.println("✅ AI chose the right text tool!");
        System.out.println();
        
        // ====================================================================
        // EXAMPLE 8: No Tool Needed
        // ====================================================================
        
        System.out.println("--- Example 8: No Tool Needed ---");
        System.out.println("User: What is the capital of France?");
        String response8 = assistant.chat("What is the capital of France?");
        System.out.println("AI: " + response8);
        System.out.println("✅ AI knew it didn't need any tools - answered from knowledge!");
        System.out.println();
        
        /*
         * ====================================================================
         * KEY OBSERVATIONS:
         * ====================================================================
         * 
         * 1. AUTOMATIC TOOL SELECTION
         *    - AI analyzes question
         *    - Determines which tool(s) needed
         *    - Calls them in correct order
         * 
         * 2. TOOL COMPOSITION
         *    - Can use multiple tools for one question
         *    - Results from one tool inform next tool choice
         *    - Final answer synthesizes all tool results
         * 
         * 3. INTELLIGENT DECISION MAKING
         *    - Knows when tools are NOT needed
         *    - Chooses most appropriate tool
         *    - Handles tool failures gracefully
         * 
         * 4. STATEFUL TOOLS
         *    - Some tools maintain state (DataStorageTools)
         *    - Useful for remembering user preferences
         *    - Different from conversation memory!
         * 
         * ====================================================================
         * TOOL DESIGN PATTERNS:
         * ====================================================================
         * 
         * 1. SINGLE RESPONSIBILITY
         *    Each tool does ONE thing well
         *    ✅ getTime(), getDate(), getDayOfWeek()
         *    ❌ getTimeAndDateAndDay()
         * 
         * 2. LOGICAL GROUPING
         *    Related tools in same class
         *    - TimeTools: All time-related
         *    - MathTools: All calculations
         *    - TextTools: All string operations
         * 
         * 3. CLEAR DESCRIPTIONS
         *    @Tool("Exact description of what it does")
         *    Include parameter requirements
         *    Mention format/units
         * 
         * 4. ERROR HANDLING
         *    Validate inputs
         *    Throw meaningful exceptions
         *    Return useful error messages
         * 
         * 5. IDEMPOTENCY
         *    Same inputs → Same outputs
         *    (except for inherently changing things like time)
         */
    }
    
    /**
     * Bonus: Demonstrate tool logging and debugging
     */
    public static void demonstrateToolDebugging() {
        System.out.println("=" .repeat(80));
        System.out.println("TOOL DEBUGGING & MONITORING");
        System.out.println("=" .repeat(80));
        System.out.println();
        
        /*
         * PRODUCTION TIPS:
         * 
         * 1. LOG ALL TOOL CALLS
         *    - What tool was called
         *    - What parameters
         *    - What was returned
         *    - How long it took
         * 
         * 2. MONITOR TOOL USAGE
         *    - Which tools are used most?
         *    - Which never get used?
         *    - Any failing tools?
         * 
         * 3. TRACK COSTS
         *    - Tool calls add to total tokens
         *    - Each tool call = additional LLM reasoning
         *    - Monitor and optimize
         * 
         * 4. SECURITY
         *    - Validate all tool inputs
         *    - Sanitize parameters
         *    - Rate limit expensive tools
         *    - Audit sensitive operations
         */
    }
}

/*
 * ============================================================================
 * EXERCISE IDEAS:
 * ============================================================================
 * 
 * 1. WEATHER & TRAVEL PLANNER
 *    Tools:
 *    - getWeather(city)
 *    - getFlightPrice(from, to)
 *    - convertCurrency(amount, from, to)
 *    
 *    Query: "What's the weather in Tokyo and how much would a flight cost from NYC?"
 * 
 * 2. E-COMMERCE ASSISTANT
 *    Tools:
 *    - searchProducts(query)
 *    - getProductDetails(productId)
 *    - calculateShipping(weight, distance)
 *    - applyDiscount(price, couponCode)
 *    
 *    Query: "Find a laptop under $1000 and calculate total with shipping to CA"
 * 
 * 3. CODE ASSISTANT
 *    Tools:
 *    - analyzeCode(code)
 *    - runTests(testFile)
 *    - checkStyle(code)
 *    - suggestRefactoring(code)
 *    
 *    Query: "Analyze this code, run tests, and suggest improvements"
 * 
 * 4. HEALTH TRACKER
 *    Tools:
 *    - logMeal(food, calories)
 *    - getCalories(food)
 *    - calculateBMI(weight, height)
 *    - suggestWorkout(fitnessLevel)
 *    
 *    Query: "I ate a burger. How many calories? Should I work out?"
 * 
 * ============================================================================
 * ADVANCED TOPICS:
 * ============================================================================
 * 
 * 1. ASYNC TOOLS
 *    For slow operations (API calls, database queries):
 *    ```java
 *    @Tool("...")
 *    public CompletableFuture<String> slowOperation() {
 *        return CompletableFuture.supplyAsync(() -> {
 *            // Long running operation
 *        });
 *    }
 *    ```
 * 
 * 2. TOOL PERMISSIONS
 *    Restrict which tools certain users can access
 * 
 * 3. TOOL VERSIONING
 *    Handle tool updates gracefully
 * 
 * 4. CONDITIONAL TOOLS
 *    Only provide tools based on context
 *    (e.g., admin tools only for admin users)
 */

