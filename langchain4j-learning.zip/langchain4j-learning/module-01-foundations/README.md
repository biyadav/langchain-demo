# Module 1: Foundations

## 🎯 Learning Goals

By the end of this module, you will:
- Understand what LangChain4j is and why it exists
- Make your first LLM call
- Use prompt templates
- Understand chat vs completion models
- Handle responses

## 📚 Theory

### What is LangChain4j?

LangChain4j is a Java framework that simplifies building applications with Large Language Models (LLMs). It provides:

1. **Abstraction Layer**: Work with different LLM providers (OpenAI, Anthropic, local models) using the same API
2. **Prompt Management**: Templates, variables, and structured prompts
3. **Memory Systems**: Maintain conversation context
4. **Tool Integration**: Let AI use external tools and APIs
5. **RAG Support**: Retrieval Augmented Generation with document stores
6. **Production Ready**: Error handling, retry logic, observability

### Why LangChain4j vs Spring AI?

| Feature | LangChain4j | Spring AI |
|---------|-------------|-----------|
| **Maturity** | More mature, stable | Newer, evolving |
| **Provider Support** | 20+ providers | Growing support |
| **RAG Features** | Extensive | Basic |
| **Learning Curve** | Moderate | Easy for Spring devs |
| **Documentation** | Excellent | Growing |
| **Community** | Large | Growing fast |

**Use LangChain4j when:**
- You need advanced features (complex RAG, multiple agents)
- You want provider flexibility
- You need battle-tested libraries

**Use Spring AI when:**
- You're already using Spring Boot
- You prefer Spring conventions
- You need simpler use cases

### Core Concepts

#### 1. Chat Language Model
Conversational AI that maintains context across messages.

```
User: "What's the capital of France?"
AI: "The capital of France is Paris."
User: "What's its population?"
AI: "Paris has approximately 2.2 million residents..."
```

#### 2. Language Model (Completion)
Text completion without conversation context.

```
Input: "Once upon a time"
Output: "in a land far away, there lived a brave knight..."
```

#### 3. Prompt Template
Reusable prompts with variables.

```
Template: "Translate '{{text}}' from {{sourceLanguage}} to {{targetLanguage}}"
Variables: text="Hello", sourceLanguage="English", targetLanguage="Spanish"
Result: "Translate 'Hello' from English to Spanish"
```

### Architecture Overview

```
Your Application
      ↓
LangChain4j API
      ↓
Provider Adapter (OpenAI, Anthropic, etc.)
      ↓
LLM Service
```

## 💻 Examples

### Example 1: Hello World
**File**: `Example01_HelloWorld.java`

Simple first interaction with an LLM.

**Concepts**:
- Creating a chat model
- Sending a message
- Getting a response

### Example 2: Prompt Templates
**File**: `Example02_PromptTemplates.java`

Using templates for dynamic prompts.

**Concepts**:
- PromptTemplate
- Variable substitution
- Reusable prompts

### Example 3: System Messages
**File**: `Example03_SystemMessages.java`

Defining AI behavior with system prompts.

**Concepts**:
- System vs User messages
- Persona definition
- Behavior control

### Example 4: Streaming Responses
**File**: `Example04_Streaming.java`

Real-time streaming of AI responses.

**Concepts**:
- StreamingChatLanguageModel
- Token-by-token output
- User experience improvement

## 🎓 Key Takeaways

1. **LangChain4j simplifies LLM integration** - One API for multiple providers
2. **Prompt templates are powerful** - Reuse and parameterize your prompts
3. **System messages define behavior** - Set the AI's role and constraints
4. **Streaming improves UX** - Show results as they generate

## ✅ Exercises

### Exercise 1: Personal Assistant
Create a chat application where the AI acts as a personal assistant. Use a system message to define its personality.

**Requirements**:
- Friendly, professional tone
- Concise responses
- Always ends with a question to continue the conversation

### Exercise 2: Language Translator
Build a translation service using prompt templates.

**Requirements**:
- Template with source language, target language, and text
- Support at least 3 languages
- Handle edge cases (empty text, same source/target)

### Exercise 3: Story Generator
Create a story generator with parameters.

**Requirements**:
- Template with: genre, main character, setting
- Generate 3-paragraph story
- Use streaming for better UX

## 📖 Additional Reading

- [LangChain4j Docs: Getting Started](https://docs.langchain4j.dev/intro/)
- [LangChain4j GitHub Examples](https://github.com/langchain4j/langchain4j-examples)
- [Prompt Engineering Guide](https://www.promptingguide.ai/)

## ➡️ Next Module

Once you're comfortable with these concepts, move to **Module 2: Structured Interactions** to learn about AI Services and type-safe LLM interactions!

