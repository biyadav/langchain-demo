package module01.examples;

import dev.langchain4j.model.chat.ChatLanguageModel;
import dev.langchain4j.model.openai.OpenAiChatModel;

/**
 * Example 1: Hello World with LangChain4j
 * 
 * This is the simplest possible example - sending a message to an LLM
 * and getting a response.
 * 
 * Concepts:
 * - ChatLanguageModel interface
 * - OpenAiChatModel implementation
 * - Synchronous chat completion
 */
public class Example01_HelloWorld {
    
    public static void main(String[] args) {
        
        // Step 1: Create a chat model
        // This connects to OpenAI's GPT models
        ChatLanguageModel model = OpenAiChatModel.builder()
            .apiKey(System.getenv("OPENAI_API_KEY"))  // Get from environment
            .modelName("gpt-4o-mini")                  // Model to use
            .temperature(0.7)                          // Creativity (0.0-1.0)
            .build();
        
        // Step 2: Send a message
        String userMessage = "Explain what LangChain4j is in one sentence.";
        
        System.out.println("User: " + userMessage);
        System.out.println("Thinking...\n");
        
        // Step 3: Get response
        String response = model.generate(userMessage);
        
        System.out.println("AI: " + response);
        
        /*
         * EXPLANATION:
         * 
         * 1. ChatLanguageModel: Interface for all chat models
         *    - Allows switching providers easily (OpenAI, Anthropic, etc.)
         *    
         * 2. OpenAiChatModel: Specific implementation for OpenAI
         *    - apiKey: Your OpenAI API key
         *    - modelName: Which model to use (gpt-4, gpt-3.5-turbo, etc.)
         *    - temperature: Controls randomness
         *      * 0.0 = deterministic, same answer every time
         *      * 1.0 = creative, varied answers
         *      
         * 3. generate(): Sends message, waits for complete response
         */
    }
}

/*
 * TO RUN THIS EXAMPLE:
 * 
 * 1. Set your OpenAI API key:
 *    export OPENAI_API_KEY=sk-your-key-here
 *    
 * 2. Run the program:
 *    java Example01_HelloWorld.java
 *    
 * 3. Expected output:
 *    User: Explain what LangChain4j is in one sentence.
 *    Thinking...
 *    
 *    AI: LangChain4j is a Java library that simplifies building 
 *        applications powered by large language models.
 *        
 * EXPERIMENT:
 * - Try different questions
 * - Change temperature and observe differences
 * - Try different models (gpt-4, gpt-3.5-turbo)
 */

