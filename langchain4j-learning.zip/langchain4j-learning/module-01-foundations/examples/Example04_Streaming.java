package module01.examples;

import dev.langchain4j.model.StreamingResponseHandler;
import dev.langchain4j.model.chat.StreamingChatLanguageModel;
import dev.langchain4j.model.openai.OpenAiStreamingChatModel;
import dev.langchain4j.model.output.Response;

/**
 * Example 4: Streaming Responses
 * 
 * Streaming shows tokens as they're generated, creating a better user experience.
 * Like ChatGPT's typing effect!
 * 
 * Concepts:
 * - StreamingChatLanguageModel
 * - StreamingResponseHandler
 * - Token-by-token processing
 */
public class Example04_Streaming {
    
    public static void main(String[] args) throws InterruptedException {
        
        // Create a STREAMING model (different from regular ChatLanguageModel)
        StreamingChatLanguageModel model = OpenAiStreamingChatModel.builder()
            .apiKey(System.getenv("OPENAI_API_KEY"))
            .modelName("gpt-4o-mini")
            .build();
        
        // ============================================
        // EXAMPLE 1: Simple Streaming
        // ============================================
        
        System.out.println("=== Simple Streaming ===\n");
        System.out.println("AI: ");
        
        String prompt = "Write a 3-sentence story about a robot learning to code.";
        
        model.generate(prompt, new StreamingResponseHandler<>() {
            
            @Override
            public void onNext(String token) {
                // Called for each token as it arrives
                System.out.print(token);
            }
            
            @Override
            public void onComplete(Response<String> response) {
                // Called when streaming is done
                System.out.println("\n\n[Streaming complete]");
            }
            
            @Override
            public void onError(Throwable error) {
                // Called if there's an error
                System.err.println("Error: " + error.getMessage());
            }
        });
        
        // Wait for streaming to complete
        Thread.sleep(5000);
        
        // ============================================
        // EXAMPLE 2: Streaming with Processing
        // ============================================
        
        System.out.println("\n=== Streaming with Processing ===\n");
        
        StringBuilder fullResponse = new StringBuilder();
        int[] tokenCount = {0};  // Array to allow modification in lambda
        
        model.generate(
            "List 5 benefits of streaming responses:",
            new StreamingResponseHandler<>() {
                
                @Override
                public void onNext(String token) {
                    System.out.print(token);
                    fullResponse.append(token);
                    tokenCount[0]++;
                }
                
                @Override
                public void onComplete(Response<String> response) {
                    System.out.println("\n\n--- Statistics ---");
                    System.out.println("Total tokens received: " + tokenCount[0]);
                    System.out.println("Total characters: " + fullResponse.length());
                    System.out.println("Response length: " + response.content().length());
                }
                
                @Override
                public void onError(Throwable error) {
                    System.err.println("Error occurred: " + error.getMessage());
                }
            }
        );
        
        Thread.sleep(5000);
        
        /*
         * WHY USE STREAMING?
         * 
         * 1. BETTER UX
         *    - Users see progress immediately
         *    - Feels faster (even if total time is same)
         *    - Like ChatGPT's typing effect
         *    
         * 2. EARLY PROCESSING
         *    - Can start processing before complete
         *    - Update UI progressively
         *    - Cancel if needed
         *    
         * 3. LONG RESPONSES
         *    - Don't wait for entire response
         *    - Show content as available
         *    - Reduce perceived latency
         *    
         * WHEN TO USE:
         * - Web applications (with Server-Sent Events)
         * - CLI tools
         * - Long-form content generation
         * - Interactive experiences
         */
    }
    
    /**
     * Real-world example: Streaming chat application
     */
    public static class StreamingChatApp {
        private final StreamingChatLanguageModel model;
        
        public StreamingChatApp(String apiKey) {
            this.model = OpenAiStreamingChatModel.builder()
                .apiKey(apiKey)
                .modelName("gpt-4o-mini")
                .build();
        }
        
        public void chat(String userMessage, ChatCallback callback) {
            model.generate(userMessage, new StreamingResponseHandler<>() {
                
                @Override
                public void onNext(String token) {
                    callback.onToken(token);
                }
                
                @Override
                public void onComplete(Response<String> response) {
                    callback.onComplete(response.content());
                }
                
                @Override
                public void onError(Throwable error) {
                    callback.onError(error);
                }
            });
        }
        
        public interface ChatCallback {
            void onToken(String token);
            void onComplete(String fullResponse);
            void onError(Throwable error);
        }
    }
}

/*
 * STREAMING IN WEB APPLICATIONS:
 * 
 * Use Server-Sent Events (SSE) or WebSockets:
 * 
 * @GetMapping(value = "/chat/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
 * public Flux<String> streamChat(@RequestParam String message) {
 *     return Flux.create(sink -> {
 *         model.generate(message, new StreamingResponseHandler<>() {
 *             public void onNext(String token) {
 *                 sink.next(token);
 *             }
 *             public void onComplete(Response<String> response) {
 *                 sink.complete();
 *             }
 *             public void onError(Throwable error) {
 *                 sink.error(error);
 *             }
 *         });
 *     });
 * }
 * 
 * EXPERIMENT:
 * - Build a CLI chat with streaming
 * - Implement a progress indicator
 * - Add ability to cancel streaming
 * - Count words as they stream in
 */

