package module01.examples;

import dev.langchain4j.model.chat.ChatLanguageModel;
import dev.langchain4j.model.openai.OpenAiChatModel;
import dev.langchain4j.model.input.PromptTemplate;

import java.util.HashMap;
import java.util.Map;

/**
 * Example 2: Using Prompt Templates
 * 
 * Prompt templates allow you to create reusable prompts with variables.
 * This is essential for building maintainable applications.
 * 
 * Concepts:
 * - PromptTemplate creation
 * - Variable substitution
 * - Template reuse
 */
public class Example02_PromptTemplates {
    
    public static void main(String[] args) {
        
        // Create the model
        ChatLanguageModel model = OpenAiChatModel.builder()
            .apiKey(System.getenv("OPENAI_API_KEY"))
            .modelName("gpt-4o-mini")
            .build();
        
        // ============================================
        // SIMPLE TEMPLATE
        // ============================================
        
        System.out.println("=== Simple Template ===\n");
        
        // Define a template with placeholders
        PromptTemplate simpleTemplate = PromptTemplate.from(
            "What is the capital of {{country}}?"
        );
        
        // Create variables
        Map<String, Object> variables = new HashMap<>();
        variables.put("country", "Japan");
        
        // Apply template
        String prompt = simpleTemplate.apply(variables).text();
        
        System.out.println("Prompt: " + prompt);
        System.out.println("AI: " + model.generate(prompt) + "\n");
        
        // ============================================
        // TRANSLATION TEMPLATE
        // ============================================
        
        System.out.println("=== Translation Template ===\n");
        
        PromptTemplate translationTemplate = PromptTemplate.from(
            """
            Translate the following text from {{sourceLanguage}} to {{targetLanguage}}:
            
            Text: {{text}}
            
            Provide only the translation, nothing else.
            """
        );
        
        // Use same template multiple times with different variables
        String[] texts = {"Hello, how are you?", "Good morning!", "Thank you"};
        
        for (String text : texts) {
            Map<String, Object> vars = new HashMap<>();
            vars.put("sourceLanguage", "English");
            vars.put("targetLanguage", "Spanish");
            vars.put("text", text);
            
            String translationPrompt = translationTemplate.apply(vars).text();
            String translation = model.generate(translationPrompt);
            
            System.out.println(text + " → " + translation);
        }
        
        // ============================================
        // STRUCTURED TEMPLATE
        // ============================================
        
        System.out.println("\n=== Structured Template ===\n");
        
        PromptTemplate reviewTemplate = PromptTemplate.from(
            """
            Analyze this {{itemType}} review:
            
            Review: "{{reviewText}}"
            Rating: {{rating}}/5 stars
            
            Provide:
            1. Sentiment (Positive/Neutral/Negative)
            2. Key points (bullet list)
            3. Recommendation (Yes/No/Maybe)
            
            Be concise and objective.
            """
        );
        
        Map<String, Object> reviewVars = new HashMap<>();
        reviewVars.put("itemType", "product");
        reviewVars.put("reviewText", "The quality is amazing but shipping took forever!");
        reviewVars.put("rating", 4);
        
        String reviewPrompt = reviewTemplate.apply(reviewVars).text();
        System.out.println(model.generate(reviewPrompt));
        
        /*
         * BENEFITS OF TEMPLATES:
         * 
         * 1. REUSABILITY
         *    - Write once, use many times
         *    - Consistent prompting across application
         *    
         * 2. MAINTAINABILITY
         *    - Change prompt logic in one place
         *    - Easy to test and improve
         *    
         * 3. FLEXIBILITY
         *    - Dynamic content
         *    - User-specific customization
         *    
         * 4. SAFETY
         *    - Prevents prompt injection
         *    - Validated variable substitution
         */
    }
    
    /**
     * Helper: Example of template in a service method
     */
    public static String translateText(
            ChatLanguageModel model,
            String text,
            String fromLang,
            String toLang) {
        
        PromptTemplate template = PromptTemplate.from(
            "Translate '{{text}}' from {{from}} to {{to}}"
        );
        
        Map<String, Object> vars = new HashMap<>();
        vars.put("text", text);
        vars.put("from", fromLang);
        vars.put("to", toLang);
        
        String prompt = template.apply(vars).text();
        return model.generate(prompt);
    }
}

/*
 * BEST PRACTICES:
 * 
 * 1. Use templates for ANY prompt that:
 *    - Will be used more than once
 *    - Has variable parts
 *    - Needs consistency
 *    
 * 2. Store templates externally:
 *    - In files (templates/translation.txt)
 *    - In database
 *    - In configuration
 *    
 * 3. Name variables clearly:
 *    - {{userName}} not {{u}}
 *    - {{sourceLanguage}} not {{lang1}}
 *    
 * 4. Document expected variables:
 *    - What each variable is
 *    - Type and format
 *    - Required vs optional
 *    
 * EXPERIMENT:
 * - Create a template for code review
 * - Build a template for email generation
 * - Make a multi-step template with instructions
 */

