package module01.examples;

import dev.langchain4j.data.message.AiMessage;
import dev.langchain4j.data.message.SystemMessage;
import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.model.chat.ChatLanguageModel;
import dev.langchain4j.model.openai.OpenAiChatModel;
import dev.langchain4j.model.output.Response;

/**
 * Example 3: System Messages
 * 
 * System messages define the AI's behavior, personality, and constraints.
 * They're incredibly powerful for shaping responses.
 * 
 * Concepts:
 * - SystemMessage vs UserMessage
 * - Persona definition
 * - Behavior control
 * - Multi-message conversations
 */
public class Example03_SystemMessages {
    
    public static void main(String[] args) {
        
        ChatLanguageModel model = OpenAiChatModel.builder()
            .apiKey(System.getenv("OPENAI_API_KEY"))
            .modelName("gpt-4o-mini")
            .build();
        
        // ============================================
        // EXAMPLE 1: Professional Assistant
        // ============================================
        
        System.out.println("=== Professional Assistant ===\n");
        
        SystemMessage professionalSystem = SystemMessage.from(
            """
            You are a professional business assistant. 
            - Be formal and concise
            - Use business terminology
            - Always provide actionable insights
            - End responses with "How else may I assist?"
            """
        );
        
        UserMessage question1 = UserMessage.from(
            "How do I improve team productivity?"
        );
        
        Response<AiMessage> response1 = model.generate(
            professionalSystem,
            question1
        );
        
        System.out.println("User: " + question1.text());
        System.out.println("AI: " + response1.content().text() + "\n");
        
        // ============================================
        // EXAMPLE 2: Friendly Tutor
        // ============================================
        
        System.out.println("=== Friendly Tutor ===\n");
        
        SystemMessage tutorSystem = SystemMessage.from(
            """
            You are a patient, friendly tutor teaching programming to beginners.
            - Use simple language
            - Include examples in every explanation
            - Be encouraging and supportive
            - Break complex topics into small steps
            - Use emojis to make it fun 🎓
            """
        );
        
        UserMessage question2 = UserMessage.from(
            "What is a variable in programming?"
        );
        
        Response<AiMessage> response2 = model.generate(
            tutorSystem,
            question2
        );
        
        System.out.println("Student: " + question2.text());
        System.out.println("Tutor: " + response2.content().text() + "\n");
        
        // ============================================
        // EXAMPLE 3: Technical Expert
        // ============================================
        
        System.out.println("=== Technical Expert ===\n");
        
        SystemMessage expertSystem = SystemMessage.from(
            """
            You are a senior Java architect with 15 years of experience.
            - Provide technically accurate information
            - Reference Java versions and features
            - Mention trade-offs and best practices
            - Use code examples
            - Be direct and precise
            """
        );
        
        UserMessage question3 = UserMessage.from(
            "Should I use Optional in Java?"
        );
        
        Response<AiMessage> response3 = model.generate(
            expertSystem,
            question3
        );
        
        System.out.println("Developer: " + question3.text());
        System.out.println("Expert: " + response3.content().text() + "\n");
        
        // ============================================
        // EXAMPLE 4: Constrained Output
        // ============================================
        
        System.out.println("=== Constrained Output ===\n");
        
        SystemMessage constrainedSystem = SystemMessage.from(
            """
            You answer questions about movies.
            
            STRICT RULES:
            1. Responses must be exactly 2 sentences
            2. First sentence: Direct answer
            3. Second sentence: One interesting fact
            4. NO additional information
            5. If you don't know, say "I don't have that information."
            """
        );
        
        UserMessage question4 = UserMessage.from(
            "Who directed Inception?"
        );
        
        Response<AiMessage> response4 = model.generate(
            constrainedSystem,
            question4
        );
        
        System.out.println("User: " + question4.text());
        System.out.println("AI: " + response4.content().text() + "\n");
        
        /*
         * SYSTEM MESSAGE BEST PRACTICES:
         * 
         * 1. BE SPECIFIC
         *    - Define exact behavior
         *    - Set clear constraints
         *    - Provide examples of desired output
         *    
         * 2. DEFINE SCOPE
         *    - What topics to cover
         *    - What to avoid
         *    - Knowledge boundaries
         *    
         * 3. SET TONE
         *    - Formal vs casual
         *    - Technical vs simple
         *    - Personality traits
         *    
         * 4. OUTPUT FORMAT
         *    - Length constraints
         *    - Structure requirements
         *    - Special formatting
         */
    }
    
    /**
     * Helper: Create a custom persona
     */
    public static String askWithPersona(
            ChatLanguageModel model,
            String systemPrompt,
            String userQuestion) {
        
        SystemMessage system = SystemMessage.from(systemPrompt);
        UserMessage user = UserMessage.from(userQuestion);
        
        Response<AiMessage> response = model.generate(system, user);
        return response.content().text();
    }
    
    /**
     * Real-world example: Customer service bot
     */
    public static class CustomerServiceBot {
        private final ChatLanguageModel model;
        private final SystemMessage systemMessage;
        
        public CustomerServiceBot(ChatLanguageModel model) {
            this.model = model;
            this.systemMessage = SystemMessage.from(
                """
                You are a customer service representative for TechStore.
                
                YOUR ROLE:
                - Help customers with orders, returns, and product questions
                - Be empathetic and professional
                - Escalate to human if: refunds > $100, angry customers, technical issues
                
                AVAILABLE ACTIONS:
                - Check order status
                - Initiate return
                - Answer product questions
                
                RESPONSE FORMAT:
                1. Acknowledge the customer's concern
                2. Provide solution or next steps
                3. Ask if they need anything else
                
                TONE: Friendly, helpful, apologetic when needed
                """
            );
        }
        
        public String respond(String customerMessage) {
            UserMessage user = UserMessage.from(customerMessage);
            Response<AiMessage> response = model.generate(systemMessage, user);
            return response.content().text();
        }
    }
}

/*
 * EXERCISE IDEAS:
 * 
 * 1. Create a code reviewer bot:
 *    - Checks for best practices
 *    - Suggests improvements
 *    - Explains reasoning
 *    
 * 2. Build a creative writer:
 *    - Writes in specific genres
 *    - Maintains consistent tone
 *    - Follows story structure
 *    
 * 3. Make a data analyst:
 *    - Interprets numbers
 *    - Suggests visualizations
 *    - Provides actionable insights
 *    
 * EXPERIMENT:
 * - Try the same question with different system prompts
 * - Create personas for different use cases
 * - Test how specific vs general system messages affect output
 */

