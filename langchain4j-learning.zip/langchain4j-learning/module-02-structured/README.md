# Module 2: Structured Interactions with AI Services

## 🎯 Learning Goals

By the end of this module, you will:
- Understand AI Services and their benefits
- Use annotations for type-safe LLM interactions
- Extract structured data from LLM responses
- Handle complex return types
- Build maintainable AI-powered services

## 📚 Theory

### What are AI Services?

AI Services in LangChain4j allow you to define LLM interactions using **interfaces**. Instead of manually constructing prompts and parsing responses, you:

1. Define an interface
2. Annotate methods with prompts
3. LangChain4j generates the implementation

**Benefits:**
- Type-safe
- Less boilerplate code
- Easier testing (can mock)
- Self-documenting
- Automatic response parsing

### Traditional Approach vs AI Services

#### Traditional Way:
```java
String prompt = "Translate 'Hello' to Spanish";
String response = model.generate(prompt);
// response is unstructured text
```

#### AI Services Way:
```java
interface Translator {
    @UserMessage("Translate '{{text}}' to Spanish")
    String translate(String text);
}

Translator translator = AiServices.create(Translator.class, model);
String result = translator.translate("Hello");
// result is a String, guaranteed
```

### Key Annotations

| Annotation | Purpose | Example |
|------------|---------|---------|
| `@SystemMessage` | Define AI behavior | `@SystemMessage("You are a poet")` |
| `@UserMessage` | User's message | `@UserMessage("Write about {{topic}}")` |
| `@V` | Variable in template | `String write(@V("topic") String t)` |
| `@UserName` | Set user name | For multi-user scenarios |

### Response Types

AI Services support various return types:

```java
interface MyService {
    String getSimpleResponse();           // Plain text
    int extractNumber();                  // Parsed number
    boolean isPositive();                 // Boolean
    List<String> getList();              // Lists
    MyCustomClass extractData();         // POJOs
    Result<String> getWithMetadata();    // With token usage
}
```

## 💻 Examples

### Example 1: Basic AI Service
**File**: `Example01_BasicAIService.java`

Creating your first AI Service with simple methods.

**Concepts**:
- Interface definition
- @UserMessage annotation
- Creating service instance
- Method invocation

### Example 2: Structured Extraction
**File**: `Example02_StructuredExtraction.java`

Extracting structured data (POJOs) from text.

**Concepts**:
- Defining data classes
- Automatic JSON parsing
- Complex object extraction
- Nested structures

### Example 3: Dynamic Prompts
**File**: `Example03_DynamicPrompts.java`

Using variables and parameters in prompts.

**Concepts**:
- @V annotation
- Multiple parameters
- Template variable substitution
- Reusable prompts

### Example 4: System Messages
**File**: `Example04_SystemMessages.java`

Combining system and user messages in AI Services.

**Concepts**:
- @SystemMessage annotation
- Defining persona
- Consistent behavior
- Role-based responses

## 🎓 Key Takeaways

1. **AI Services reduce boilerplate** - No manual prompt construction
2. **Type safety is powerful** - Catch errors at compile time
3. **Structured extraction is easy** - Define POJOs, get data
4. **Annotations are expressive** - Self-documenting code

## ✅ Exercises

### Exercise 1: Sentiment Analyzer
Create an AI Service that analyzes text sentiment.

**Requirements**:
- Method: `Sentiment analyze(String text)`
- Return object with: sentiment, confidence, keywords
- Support positive, negative, neutral

### Exercise 2: Code Reviewer
Build a service that reviews code snippets.

**Requirements**:
- Input: code string, language
- Output: Review object with issues, suggestions, score
- Different system prompts for different languages

### Exercise 3: Data Extractor
Create a service that extracts structured data from unstructured text.

**Requirements**:
- Extract person info from text (name, age, occupation)
- Extract event details (date, location, attendees)
- Handle missing information gracefully

## 📖 Additional Reading

- [LangChain4j AI Services Docs](https://docs.langchain4j.dev/tutorials/ai-services)
- [JSON Mode and Structured Outputs](https://platform.openai.com/docs/guides/structured-outputs)
- [Prompt Engineering for Data Extraction](https://www.promptingguide.ai/)

## ➡️ Next Module

Ready for **Module 3: Memory Systems** to add conversation history and context!

