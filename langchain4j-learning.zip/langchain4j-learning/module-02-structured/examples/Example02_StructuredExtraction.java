package module02.examples;

import dev.langchain4j.model.chat.ChatLanguageModel;
import dev.langchain4j.model.openai.OpenAiChatModel;
import dev.langchain4j.service.AiServices;
import dev.langchain4j.service.UserMessage;
import dev.langchain4j.service.V;

import java.time.LocalDate;
import java.util.List;

/**
 * Example 2: Structured Data Extraction
 * 
 * Extract structured data (POJOs) from unstructured text.
 * LangChain4j automatically converts LLM responses to Java objects!
 * 
 * Concepts:
 * - Returning POJOs from AI Services
 * - Automatic JSON parsing
 * - Complex object extraction
 * - Lists and nested objects
 */
public class Example02_StructuredExtraction {
    
    // ============================================
    // DATA CLASSES
    // ============================================
    
    /**
     * Simple data class for person information
     */
    static class Person {
        String name;
        int age;
        String occupation;
        String city;
        
        @Override
        public String toString() {
            return String.format(
                "Person{name='%s', age=%d, occupation='%s', city='%s'}",
                name, age, occupation, city
            );
        }
    }
    
    /**
     * Movie information with multiple fields
     */
    static class Movie {
        String title;
        int releaseYear;
        String director;
        List<String> genres;
        double rating;
        String plot;
        
        @Override
        public String toString() {
            return String.format(
                "Movie{title='%s', year=%d, director='%s', genres=%s, rating=%.1f}",
                title, releaseYear, director, genres, rating
            );
        }
    }
    
    /**
     * Recipe with nested ingredients
     */
    static class Recipe {
        String name;
        List<Ingredient> ingredients;
        List<String> steps;
        int prepTimeMinutes;
        int servings;
        
        static class Ingredient {
            String name;
            String amount;
            
            @Override
            public String toString() {
                return amount + " " + name;
            }
        }
        
        @Override
        public String toString() {
            return String.format(
                "Recipe{name='%s', servings=%d, prepTime=%d min, ingredients=%s}",
                name, servings, prepTimeMinutes, ingredients
            );
        }
    }
    
    // ============================================
    // AI SERVICE INTERFACES
    // ============================================
    
    /**
     * Service for extracting person information
     */
    interface PersonExtractor {
        
        @UserMessage("""
            Extract person information from this text:
            
            "{{text}}"
            
            Return a JSON object with: name, age, occupation, city
            If information is missing, use "Unknown"
            """)
        Person extractPerson(@V("text") String text);
    }
    
    /**
     * Service for extracting movie information
     */
    interface MovieExtractor {
        
        @UserMessage("""
            Extract information about the movie: {{movieName}}
            
            Include: title, releaseYear, director, genres (list), rating (out of 10), and brief plot
            """)
        Movie getMovieInfo(@V("movieName") String movieName);
    }
    
    /**
     * Service for generating recipes
     */
    interface RecipeGenerator {
        
        @UserMessage("""
            Create a recipe for {{dish}}.
            
            Include:
            - name
            - list of ingredients (each with name and amount)
            - steps (numbered list)
            - prep time in minutes
            - number of servings
            
            Make it simple and realistic.
            """)
        Recipe generateRecipe(@V("dish") String dish);
    }
    
    // ============================================
    // MAIN EXAMPLES
    // ============================================
    
    public static void main(String[] args) {
        
        ChatLanguageModel model = OpenAiChatModel.builder()
            .apiKey(System.getenv("OPENAI_API_KEY"))
            .modelName("gpt-4o-mini")
            .temperature(0.7)
            .build();
        
        // ============================================
        // EXAMPLE 1: Extract Person Info
        // ============================================
        
        System.out.println("=== Person Extraction ===\n");
        
        PersonExtractor personExtractor = AiServices.create(
            PersonExtractor.class, model
        );
        
        String text = """
            John Smith is a 35-year-old software engineer living in Seattle.
            He has been coding for over 10 years and loves building web applications.
            """;
        
        Person person = personExtractor.extractPerson(text);
        System.out.println("Extracted: " + person + "\n");
        
        // ============================================
        // EXAMPLE 2: Extract Movie Info
        // ============================================
        
        System.out.println("=== Movie Information ===\n");
        
        MovieExtractor movieExtractor = AiServices.create(
            MovieExtractor.class, model
        );
        
        Movie movie = movieExtractor.getMovieInfo("The Matrix");
        System.out.println("Movie: " + movie);
        System.out.println("Plot: " + movie.plot + "\n");
        
        // ============================================
        // EXAMPLE 3: Generate Recipe
        // ============================================
        
        System.out.println("=== Recipe Generation ===\n");
        
        RecipeGenerator recipeGenerator = AiServices.create(
            RecipeGenerator.class, model
        );
        
        Recipe recipe = recipeGenerator.generateRecipe("chocolate chip cookies");
        System.out.println(recipe);
        System.out.println("\nIngredients:");
        recipe.ingredients.forEach(ing -> System.out.println("  - " + ing));
        System.out.println("\nSteps:");
        for (int i = 0; i < recipe.steps.size(); i++) {
            System.out.println((i + 1) + ". " + recipe.steps.get(i));
        }
        
        /*
         * HOW IT WORKS:
         * 
         * 1. LangChain4j sends your prompt to the LLM
         * 2. It instructs the LLM to respond in JSON format
         * 3. The JSON response is parsed into your Java class
         * 4. You get a typed object, not a string!
         * 
         * BEHIND THE SCENES:
         * 
         * LangChain4j adds instructions like:
         * "Respond in JSON format matching this structure: ..."
         * 
         * For Person class, it might add:
         * {
         *   "name": "string",
         *   "age": "integer",
         *   "occupation": "string",
         *   "city": "string"
         * }
         */
    }
    
    /**
     * Real-world example: Resume parser
     */
    interface ResumeParser {
        
        @UserMessage("""
            Parse this resume and extract key information:
            
            {{resumeText}}
            
            Extract:
            - Candidate name
            - Email
            - Phone
            - Education (list of degrees)
            - Work experience (list with company, title, years)
            - Skills (list)
            """)
        Resume parseResume(@V("resumeText") String resume);
    }
    
    static class Resume {
        String name;
        String email;
        String phone;
        List<Education> education;
        List<WorkExperience> workExperience;
        List<String> skills;
        
        static class Education {
            String degree;
            String institution;
            int year;
        }
        
        static class WorkExperience {
            String company;
            String title;
            String duration;
        }
    }
    
    /**
     * Real-world example: Invoice extractor
     */
    interface InvoiceExtractor {
        
        @UserMessage("""
            Extract information from this invoice:
            
            {{invoiceText}}
            """)
        Invoice extractInvoice(@V("invoiceText") String invoice);
    }
    
    static class Invoice {
        String invoiceNumber;
        LocalDate date;
        String vendorName;
        String customerName;
        List<LineItem> items;
        double subtotal;
        double tax;
        double total;
        
        static class LineItem {
            String description;
            int quantity;
            double unitPrice;
            double amount;
        }
    }
}

/*
 * BEST PRACTICES:
 * 
 * 1. CLASS DESIGN
 *    - Simple POJOs
 *    - Public fields or getters/setters
 *    - Descriptive field names
 *    
 * 2. PROMPT ENGINEERING
 *    - Clearly describe expected structure
 *    - Mention all fields
 *    - Handle missing data gracefully
 *    
 * 3. ERROR HANDLING
 *    - Some LLMs are better at JSON than others
 *    - Validate extracted data
 *    - Have fallback strategies
 *    
 * 4. NESTED STRUCTURES
 *    - Keep nesting reasonable (2-3 levels max)
 *    - Use clear class names
 *    - Consider Lists vs Arrays
 *    
 * EXPERIMENT:
 * - Extract product details from descriptions
 * - Parse email signatures
 * - Extract event details from announcements
 * - Build a news article summarizer with structured output
 */

