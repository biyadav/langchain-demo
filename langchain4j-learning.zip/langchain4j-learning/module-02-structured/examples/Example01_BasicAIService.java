package module02.examples;

import dev.langchain4j.model.chat.ChatLanguageModel;
import dev.langchain4j.model.openai.OpenAiChatModel;
import dev.langchain4j.service.AiServices;
import dev.langchain4j.service.UserMessage;
import dev.langchain4j.service.V;

/**
 * Example 1: Basic AI Service
 * 
 * AI Services let you define LLM interactions using interfaces.
 * This is the recommended way to work with LangChain4j!
 * 
 * Concepts:
 * - Interface-based AI interaction
 * - @UserMessage annotation
 * - Automatic implementation generation
 * - Type-safe method calls
 */
public class Example01_BasicAIService {
    
    /**
     * Define an AI Service interface
     * 
     * Methods represent different prompts you want to send to the LLM.
     * Annotations define the prompt template.
     */
    interface Assistant {
        
        /**
         * Simple question with hardcoded prompt
         */
        @UserMessage("What is the capital of France?")
        String askAboutFrance();
        
        /**
         * Prompt with a variable using {{placeholder}} syntax
         */
        @UserMessage("What is the capital of {{country}}?")
        String getCapital(@V("country") String country);
        
        /**
         * Multiple variables
         */
        @UserMessage("Translate '{{text}}' from {{from}} to {{to}}")
        String translate(
            @V("text") String text,
            @V("from") String fromLang,
            @V("to") String toLang
        );
        
        /**
         * Longer, structured prompt
         */
        @UserMessage("""
            Explain {{topic}} in exactly {{sentences}} sentences.
            Use simple language suitable for beginners.
            """)
        String explain(
            @V("topic") String topic,
            @V("sentences") int numberOfSentences
        );
    }
    
    public static void main(String[] args) {
        
        // Create the model
        ChatLanguageModel model = OpenAiChatModel.builder()
            .apiKey(System.getenv("OPENAI_API_KEY"))
            .modelName("gpt-4o-mini")
            .build();
        
        // Create an instance of the AI Service
        // LangChain4j generates the implementation!
        Assistant assistant = AiServices.create(Assistant.class, model);
        
        // ============================================
        // Use the service like any Java interface
        // ============================================
        
        System.out.println("=== Simple Question ===");
        String answer1 = assistant.askAboutFrance();
        System.out.println(answer1 + "\n");
        
        System.out.println("=== Question with Variable ===");
        String answer2 = assistant.getCapital("Japan");
        System.out.println("Capital of Japan: " + answer2 + "\n");
        
        System.out.println("=== Translation ===");
        String translation = assistant.translate(
            "Good morning",
            "English",
            "Spanish"
        );
        System.out.println("Translation: " + translation + "\n");
        
        System.out.println("=== Explanation ===");
        String explanation = assistant.explain("recursion", 3);
        System.out.println(explanation + "\n");
        
        // ============================================
        // Try with different inputs
        // ============================================
        
        System.out.println("=== Multiple Calls ===");
        String[] countries = {"Germany", "Brazil", "India"};
        for (String country : countries) {
            System.out.println(
                country + ": " + assistant.getCapital(country)
            );
        }
        
        /*
         * WHY USE AI SERVICES?
         * 
         * 1. TYPE SAFETY
         *    - Compile-time checking
         *    - IDE autocomplete
         *    - Refactoring support
         *    
         * 2. CLEAN CODE
         *    - No manual prompt construction
         *    - No response parsing
         *    - Self-documenting
         *    
         * 3. TESTABILITY
         *    - Easy to mock
         *    - Can test without API calls
         *    - Clear interfaces
         *    
         * 4. MAINTAINABILITY
         *    - Prompts in one place
         *    - Easy to modify
         *    - Version control friendly
         */
    }
    
    /**
     * Real-world example: Customer support classifier
     */
    interface CustomerSupportClassifier {
        
        @UserMessage("""
            Classify this customer message into a category:
            
            Message: "{{message}}"
            
            Categories:
            - TECHNICAL_ISSUE
            - BILLING_QUESTION
            - FEATURE_REQUEST
            - COMPLAINT
            - PRAISE
            - OTHER
            
            Respond with ONLY the category name, nothing else.
            """)
        String classifyMessage(@V("message") String customerMessage);
    }
    
    /**
     * Example: Content moderator
     */
    interface ContentModerator {
        
        @UserMessage("""
            Analyze if this content is appropriate:
            
            Content: "{{content}}"
            
            Check for:
            - Profanity
            - Hate speech
            - Spam
            - Personal information
            
            Respond with:
            - SAFE if appropriate
            - UNSAFE if not appropriate
            - REVIEW if uncertain
            
            One word only.
            """)
        String moderateContent(@V("content") String content);
    }
}

/*
 * BEST PRACTICES:
 * 
 * 1. INTERFACE NAMING
 *    - Descriptive names (Assistant, Translator, Analyzer)
 *    - Reflects purpose
 *    
 * 2. METHOD NAMING
 *    - Verb-based (translate, analyze, classify)
 *    - Clear intent
 *    
 * 3. PROMPT DESIGN
 *    - Clear instructions
 *    - Specify output format
 *    - Include examples if needed
 *    
 * 4. VARIABLE NAMES
 *    - Match @V annotation
 *    - Descriptive
 *    - Use camelCase
 *    
 * EXPERIMENT:
 * - Create a CodeExplainer service
 * - Build an EmailWriter service
 * - Make a SentimentAnalyzer service
 */

