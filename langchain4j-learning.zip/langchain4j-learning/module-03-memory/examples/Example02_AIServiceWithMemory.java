package module03.examples;

import dev.langchain4j.memory.ChatMemory;
import dev.langchain4j.memory.chat.MessageWindowChatMemory;
import dev.langchain4j.model.chat.ChatLanguageModel;
import dev.langchain4j.model.openai.OpenAiChatModel;
import dev.langchain4j.service.AiServices;
import dev.langchain4j.service.MemoryId;
import dev.langchain4j.service.SystemMessage;
import dev.langchain4j.service.UserMessage;

import java.util.HashMap;
import java.util.Map;

/**
 * Example 2: AI Service with Memory
 * 
 * ============================================================================
 * THEORY: Stateful AI Services
 * ============================================================================
 * 
 * In Example 1, we manually managed memory. With AI Services, LangChain4j
 * handles memory automatically!
 * 
 * HOW IT WORKS:
 * 
 *   1. You call: assistant.chat("Hello")
 *   2. LangChain4j:
 *      - Retrieves conversation history from memory
 *      - Adds your message
 *      - Sends all to LLM
 *      - Stores response in memory
 *      - Returns response to you
 * 
 * You just call methods - memory is automatic! ✨
 * 
 * ============================================================================
 * MEMORY STRATEGIES:
 * ============================================================================
 * 
 * SINGLE-USER (this example):
 * One memory for all conversations
 * ┌────────────────┐
 * │ Shared Memory  │
 * └────────────────┘
 *         ↕
 *    All messages
 * 
 * MULTI-USER (with @MemoryId):
 * Separate memory per user
 * ┌──────────┐  ┌──────────┐  ┌──────────┐
 * │ User A   │  │ User B   │  │ User C   │
 * │ Memory   │  │ Memory   │  │ Memory   │
 * └──────────┘  └──────────┘  └──────────┘
 * 
 * Each user has independent conversation history.
 * 
 * ============================================================================
 * CONCEPTS DEMONSTRATED:
 * ============================================================================
 * - Automatic memory management
 * - AI Service with memory injection
 * - Multi-user memory with @MemoryId
 * - System messages with memory
 * - Memory store management
 */
public class Example02_AIServiceWithMemory {
    
    // ========================================================================
    // EXAMPLE 1: Simple AI Service with Memory
    // ========================================================================
    
    /**
     * Basic assistant interface - no @MemoryId needed for single user
     */
    interface Assistant {
        String chat(String message);
    }
    
    public static void demonstrateBasicMemory() {
        System.out.println("=" .repeat(70));
        System.out.println("EXAMPLE 1: Basic AI Service with Memory");
        System.out.println("=" .repeat(70));
        System.out.println();
        
        // Create model
        ChatLanguageModel model = OpenAiChatModel.builder()
            .apiKey(System.getenv("OPENAI_API_KEY"))
            .modelName("gpt-4o-mini")
            .build();
        
        // Create memory
        ChatMemory memory = MessageWindowChatMemory.withMaxMessages(10);
        
        // Create AI Service WITH MEMORY
        Assistant assistant = AiServices.builder(Assistant.class)
            .chatLanguageModel(model)
            .chatMemory(memory)  // Memory is automatically used!
            .build();
        
        // Now just chat normally - memory is handled automatically!
        
        System.out.println("User: Hello! My name is Sarah.");
        String response1 = assistant.chat("Hello! My name is Sarah.");
        System.out.println("AI: " + response1);
        System.out.println();
        
        System.out.println("User: I love programming in Java.");
        String response2 = assistant.chat("I love programming in Java.");
        System.out.println("AI: " + response2);
        System.out.println();
        
        System.out.println("User: What's my name and what do I love?");
        String response3 = assistant.chat("What's my name and what do I love?");
        System.out.println("AI: " + response3);
        System.out.println("✅ Memory works automatically!");
        System.out.println();
        
        /*
         * WHAT HAPPENED:
         * 1. First chat: "Hello! My name is Sarah"
         *    - LangChain4j added to memory
         *    - Sent to LLM
         *    - Response stored in memory
         * 
         * 2. Second chat: "I love programming in Java"
         *    - LangChain4j retrieved previous messages
         *    - Added new message
         *    - Sent all to LLM
         *    - Response stored
         * 
         * 3. Third chat: "What's my name..."
         *    - LangChain4j retrieved ALL previous messages
         *    - AI can answer because it has full context!
         */
    }
    
    // ========================================================================
    // EXAMPLE 2: Multi-User Memory with @MemoryId
    // ========================================================================
    
    /**
     * Assistant that supports multiple users
     * 
     * @MemoryId tells LangChain4j which memory to use for each user
     */
    interface MultiUserAssistant {
        String chat(@MemoryId String userId, String message);
    }
    
    public static void demonstrateMultiUserMemory() {
        System.out.println("=" .repeat(70));
        System.out.println("EXAMPLE 2: Multi-User Memory");
        System.out.println("=" .repeat(70));
        System.out.println();
        
        ChatLanguageModel model = OpenAiChatModel.builder()
            .apiKey(System.getenv("OPENAI_API_KEY"))
            .modelName("gpt-4o-mini")
            .build();
        
        // Create a memory store that can hold multiple conversations
        // Key = userId, Value = that user's memory
        Map<Object, ChatMemory> memoryStore = new HashMap<>();
        
        // Create AI Service with memory store
        MultiUserAssistant assistant = AiServices.builder(MultiUserAssistant.class)
            .chatLanguageModel(model)
            .chatMemoryProvider(memoryId -> {
                // This function is called for each @MemoryId
                // It returns the appropriate memory for that user
                return memoryStore.computeIfAbsent(
                    memoryId,
                    id -> MessageWindowChatMemory.withMaxMessages(10)
                );
            })
            .build();
        
        // ====================================================================
        // CONVERSATION WITH USER "alice"
        // ====================================================================
        
        System.out.println("--- Conversation with Alice ---");
        
        String alice1 = assistant.chat("alice", "Hi! I'm Alice. I love cats.");
        System.out.println("Alice: Hi! I'm Alice. I love cats.");
        System.out.println("AI: " + alice1);
        System.out.println();
        
        String alice2 = assistant.chat("alice", "What do I love?");
        System.out.println("Alice: What do I love?");
        System.out.println("AI: " + alice2);
        System.out.println("✅ Remembers Alice loves cats");
        System.out.println();
        
        // ====================================================================
        // CONVERSATION WITH USER "bob"
        // ====================================================================
        
        System.out.println("--- Conversation with Bob ---");
        
        String bob1 = assistant.chat("bob", "Hello! I'm Bob. I love dogs.");
        System.out.println("Bob: Hello! I'm Bob. I love dogs.");
        System.out.println("AI: " + bob1);
        System.out.println();
        
        String bob2 = assistant.chat("bob", "What do I love?");
        System.out.println("Bob: What do I love?");
        System.out.println("AI: " + bob2);
        System.out.println("✅ Remembers Bob loves dogs (not cats!)");
        System.out.println();
        
        // ====================================================================
        // BACK TO ALICE - Her memory is preserved!
        // ====================================================================
        
        System.out.println("--- Back to Alice ---");
        
        String alice3 = assistant.chat("alice", "What's my name again?");
        System.out.println("Alice: What's my name again?");
        System.out.println("AI: " + alice3);
        System.out.println("✅ Still remembers Alice's conversation!");
        System.out.println();
        
        // ====================================================================
        // INSPECT MEMORY STORE
        // ====================================================================
        
        System.out.println("--- Memory Store Inspection ---");
        System.out.println("Number of users in memory: " + memoryStore.size());
        memoryStore.forEach((userId, memory) -> {
            System.out.println("User '" + userId + "' has " + 
                memory.messages().size() + " messages in memory");
        });
        
        /*
         * KEY INSIGHT:
         * 
         * Each user has their own isolated memory!
         * 
         * Memory Store:
         * {
         *   "alice": [msg1, msg2, msg3, msg4, ...],
         *   "bob":   [msg1, msg2, msg3, msg4, ...]
         * }
         * 
         * When you call assistant.chat("alice", ...), 
         * it uses Alice's memory.
         * 
         * When you call assistant.chat("bob", ...),
         * it uses Bob's memory.
         * 
         * They never mix!
         */
    }
    
    // ========================================================================
    // EXAMPLE 3: AI Service with System Message + Memory
    // ========================================================================
    
    /**
     * Specialized assistant with defined personality and memory
     */
    interface PersonalTrainer {
        
        @SystemMessage("""
            You are an enthusiastic personal trainer named Coach Mike.
            - Be motivating and positive
            - Remember the user's fitness goals
            - Track their progress across conversations
            - Celebrate their achievements
            - Use fitness terminology
            """)
        String chat(@MemoryId String userId, @UserMessage String message);
    }
    
    public static void demonstratePersonalizedService() {
        System.out.println("=" .repeat(70));
        System.out.println("EXAMPLE 3: Personalized Service with Memory");
        System.out.println("=" .repeat(70));
        System.out.println();
        
        ChatLanguageModel model = OpenAiChatModel.builder()
            .apiKey(System.getenv("OPENAI_API_KEY"))
            .modelName("gpt-4o-mini")
            .build();
        
        Map<Object, ChatMemory> memoryStore = new HashMap<>();
        
        PersonalTrainer trainer = AiServices.builder(PersonalTrainer.class)
            .chatLanguageModel(model)
            .chatMemoryProvider(memoryId -> 
                memoryStore.computeIfAbsent(
                    memoryId,
                    id -> MessageWindowChatMemory.withMaxMessages(20)
                )
            )
            .build();
        
        // First session - set goals
        System.out.println("--- Day 1 ---");
        String day1 = trainer.chat("user123", 
            "Hi Coach! My goal is to run 5km without stopping.");
        System.out.println("User: Hi Coach! My goal is to run 5km without stopping.");
        System.out.println("Coach Mike: " + day1);
        System.out.println();
        
        // Later session - report progress
        System.out.println("--- Day 5 ---");
        String day5 = trainer.chat("user123", 
            "I ran 2km today without stopping!");
        System.out.println("User: I ran 2km today without stopping!");
        System.out.println("Coach Mike: " + day5);
        System.out.println("✅ Remembers the 5km goal and celebrates progress!");
        System.out.println();
        
        // Even later - ask for reminder
        System.out.println("--- Day 10 ---");
        String day10 = trainer.chat("user123", 
            "What was my original goal again?");
        System.out.println("User: What was my original goal again?");
        System.out.println("Coach Mike: " + day10);
        System.out.println("✅ Remembers from days ago!");
        System.out.println();
        
        /*
         * POWERFUL COMBINATION:
         * 
         * System Message: Defines personality and role
         * Memory: Remembers user-specific information
         * Result: Personalized, consistent experience
         * 
         * This is how you build:
         * - Personal assistants
         * - Customer support bots
         * - Educational tutors
         * - Healthcare advisors
         * - Any application needing personalization + memory
         */
    }
    
    // ========================================================================
    // MAIN METHOD - Run all examples
    // ========================================================================
    
    public static void main(String[] args) {
        demonstrateBasicMemory();
        System.out.println("\n\n");
        
        demonstrateMultiUserMemory();
        System.out.println("\n\n");
        
        demonstratePersonalizedService();
        
        /*
         * ====================================================================
         * SUMMARY: Memory in AI Services
         * ====================================================================
         * 
         * WITHOUT MEMORY:
         * assistant.chat("My name is X")  → AI responds
         * assistant.chat("What's my name?") → "I don't know" ❌
         * 
         * WITH MEMORY:
         * assistant.chat("My name is X")  → AI responds
         * assistant.chat("What's my name?") → "Your name is X" ✅
         * 
         * SINGLE USER:
         * chatMemory(memory) → One shared memory
         * 
         * MULTI USER:
         * chatMemoryProvider(...) → Separate memory per @MemoryId
         * 
         * ====================================================================
         * BEST PRACTICES:
         * ====================================================================
         * 
         * 1. SINGLE USER APPS
         *    - Use simple chatMemory(memory)
         *    - Perfect for CLI tools, personal assistants
         * 
         * 2. MULTI USER APPS
         *    - Use chatMemoryProvider with @MemoryId
         *    - Essential for web apps, APIs
         * 
         * 3. MEMORY SIZE
         *    - Start with 10-20 messages
         *    - Adjust based on use case
         *    - Monitor token usage
         * 
         * 4. PERSISTENCE
         *    - Save memory to database for production
         *    - Load on user return
         *    - Implement memory cleanup (old conversations)
         * 
         * 5. PRIVACY
         *    - Clear sensitive information
         *    - Respect user's "forget me" requests
         *    - Encrypt stored conversations
         */
    }
}

/*
 * ============================================================================
 * EXERCISE IDEAS:
 * ============================================================================
 * 
 * 1. SHOPPING ASSISTANT
 *    - Remember items user is interested in
 *    - Track budget across conversation
 *    - Make recommendations based on preferences
 * 
 * 2. LANGUAGE TUTOR
 *    - Remember words user has learned
 *    - Track mistakes and review them
 *    - Personalize difficulty level
 * 
 * 3. MEETING SCHEDULER
 *    - Remember user's availability preferences
 *    - Track scheduled meetings
 *    - Suggest times based on history
 * 
 * 4. CODE REVIEWER
 *    - Remember code style preferences
 *    - Track recurring issues
 *    - Learn from feedback
 * 
 * ============================================================================
 * PRODUCTION CONSIDERATIONS:
 * ============================================================================
 * 
 * For real applications, implement:
 * 
 * 1. PERSISTENT STORAGE
 *    ```java
 *    interface ChatMemoryStore {
 *        void save(String userId, List<ChatMessage> messages);
 *        List<ChatMessage> load(String userId);
 *    }
 *    ```
 * 
 * 2. MEMORY EVICTION
 *    - Old conversations cleanup
 *    - Inactive user memory removal
 *    - Archive instead of delete
 * 
 * 3. MONITORING
 *    - Track memory usage per user
 *    - Alert on unusually large memories
 *    - Cost attribution per user
 * 
 * 4. SECURITY
 *    - Encrypt stored conversations
 *    - Access control
 *    - Audit logs
 */

