package module03.examples;

import dev.langchain4j.data.message.AiMessage;
import dev.langchain4j.data.message.ChatMessage;
import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.memory.ChatMemory;
import dev.langchain4j.memory.chat.MessageWindowChatMemory;
import dev.langchain4j.model.chat.ChatLanguageModel;
import dev.langchain4j.model.openai.OpenAiChatModel;

import java.util.List;

/**
 * Example 1: Basic Chat Memory
 * 
 * ============================================================================
 * THEORY: What is Chat Memory?
 * ============================================================================
 * 
 * Chat Memory stores the conversation history between user and AI.
 * Without memory, each message is independent:
 * 
 *   User: "My name is John"
 *   AI: "Nice to meet you!"
 *   User: "What's my name?"
 *   AI: "I don't know your name" ❌
 * 
 * With memory, the AI remembers previous context:
 * 
 *   User: "My name is John"
 *   AI: "Nice to meet you, John!"
 *   User: "What's my name?"
 *   AI: "Your name is John!" ✅
 * 
 * ============================================================================
 * HOW MEMORY WORKS:
 * ============================================================================
 * 
 * 1. User sends message → Stored in memory
 * 2. Memory retrieves recent messages → Sent to LLM as context
 * 3. LLM generates response → Response stored in memory
 * 4. Next message has full conversation history
 * 
 * Memory Structure:
 * ┌─────────────────────────────────────┐
 * │ ChatMemory                          │
 * ├─────────────────────────────────────┤
 * │ [UserMessage] "My name is John"     │
 * │ [AiMessage] "Nice to meet you!"     │
 * │ [UserMessage] "What's my name?"     │
 * │ [AiMessage] "Your name is John"     │
 * └─────────────────────────────────────┘
 * 
 * ============================================================================
 * MESSAGE WINDOW MEMORY:
 * ============================================================================
 * 
 * MessageWindowChatMemory keeps the last N messages.
 * 
 * Example with maxMessages = 4:
 * 
 *   [msg1, msg2, msg3, msg4, msg5, msg6]
 *                └──────────┬──────────┘
 *                    Kept: [msg3, msg4, msg5, msg6]
 * 
 * Older messages are automatically removed.
 * 
 * ============================================================================
 * CONCEPTS DEMONSTRATED:
 * ============================================================================
 * - Creating ChatMemory
 * - Adding messages manually
 * - Retrieving conversation history
 * - How memory affects responses
 * - Memory capacity management
 */
public class Example01_BasicChatMemory {
    
    public static void main(String[] args) {
        
        // ========================================================================
        // SETUP: Create model and memory
        // ========================================================================
        
        ChatLanguageModel model = OpenAiChatModel.builder()
            .apiKey(System.getenv("OPENAI_API_KEY"))
            .modelName("gpt-4o-mini")
            .temperature(0.7)
            .build();
        
        // Create memory that stores last 10 messages (5 exchanges)
        // Each exchange = 1 user message + 1 AI response = 2 messages
        ChatMemory memory = MessageWindowChatMemory.withMaxMessages(10);
        
        System.out.println("=" .repeat(70));
        System.out.println("EXAMPLE 1: Conversation WITH Memory");
        System.out.println("=" .repeat(70));
        System.out.println();
        
        // ========================================================================
        // CONVERSATION 1: Introduction
        // ========================================================================
        
        System.out.println("--- Turn 1: User introduces themselves ---");
        
        // Create user message
        UserMessage userMessage1 = UserMessage.from("Hi! My name is Alice and I'm 28 years old.");
        
        // Add to memory
        memory.add(userMessage1);
        
        // Get all messages from memory to send to LLM
        List<ChatMessage> messages1 = memory.messages();
        
        // Generate response with context
        String response1 = model.generate(messages1).content().text();
        
        // Add AI response to memory
        memory.add(AiMessage.from(response1));
        
        System.out.println("User: " + userMessage1.text());
        System.out.println("AI: " + response1);
        System.out.println("Memory size: " + memory.messages().size() + " messages");
        System.out.println();
        
        // ========================================================================
        // CONVERSATION 2: Ask about previous information
        // ========================================================================
        
        System.out.println("--- Turn 2: Reference to previous information ---");
        
        UserMessage userMessage2 = UserMessage.from("What's my name and how old am I?");
        memory.add(userMessage2);
        
        // Now memory contains:
        // [UserMessage("Hi! My name is Alice..."), 
        //  AiMessage("Nice to meet you..."),
        //  UserMessage("What's my name...")]
        
        String response2 = model.generate(memory.messages()).content().text();
        memory.add(AiMessage.from(response2));
        
        System.out.println("User: " + userMessage2.text());
        System.out.println("AI: " + response2);
        System.out.println("Memory size: " + memory.messages().size() + " messages");
        System.out.println();
        
        // ========================================================================
        // CONVERSATION 3: Follow-up question using context
        // ========================================================================
        
        System.out.println("--- Turn 3: Follow-up with context ---");
        
        UserMessage userMessage3 = UserMessage.from("In 5 years, how old will I be?");
        memory.add(userMessage3);
        
        // AI can calculate because it knows Alice is 28 from memory!
        String response3 = model.generate(memory.messages()).content().text();
        memory.add(AiMessage.from(response3));
        
        System.out.println("User: " + userMessage3.text());
        System.out.println("AI: " + response3);
        System.out.println("Memory size: " + memory.messages().size() + " messages");
        System.out.println();
        
        // ========================================================================
        // CONVERSATION 4: Complex context reference
        // ========================================================================
        
        System.out.println("--- Turn 4: Complex reference ---");
        
        UserMessage userMessage4 = UserMessage.from("Summarize everything you know about me.");
        memory.add(userMessage4);
        
        String response4 = model.generate(memory.messages()).content().text();
        memory.add(AiMessage.from(response4));
        
        System.out.println("User: " + userMessage4.text());
        System.out.println("AI: " + response4);
        System.out.println("Memory size: " + memory.messages().size() + " messages");
        System.out.println();
        
        // ========================================================================
        // INSPECT MEMORY CONTENTS
        // ========================================================================
        
        System.out.println("=" .repeat(70));
        System.out.println("MEMORY INSPECTION");
        System.out.println("=" .repeat(70));
        System.out.println();
        
        List<ChatMessage> allMessages = memory.messages();
        System.out.println("Total messages in memory: " + allMessages.size());
        System.out.println();
        
        for (int i = 0; i < allMessages.size(); i++) {
            ChatMessage msg = allMessages.get(i);
            String role = msg instanceof UserMessage ? "USER" : "AI";
            System.out.println((i + 1) + ". [" + role + "] " + 
                msg.text().substring(0, Math.min(50, msg.text().length())) + "...");
        }
        System.out.println();
        
        // ========================================================================
        // COMPARISON: WITHOUT Memory
        // ========================================================================
        
        System.out.println("=" .repeat(70));
        System.out.println("EXAMPLE 2: Same Conversation WITHOUT Memory (for comparison)");
        System.out.println("=" .repeat(70));
        System.out.println();
        
        // Same questions but no memory - each is independent
        
        String noMemoryResponse1 = model.generate("Hi! My name is Bob and I'm 30.");
        System.out.println("User: Hi! My name is Bob and I'm 30.");
        System.out.println("AI: " + noMemoryResponse1);
        System.out.println();
        
        String noMemoryResponse2 = model.generate("What's my name and how old am I?");
        System.out.println("User: What's my name and how old am I?");
        System.out.println("AI: " + noMemoryResponse2);
        System.out.println("❌ AI doesn't remember because there's no memory!");
        System.out.println();
        
        /*
         * ====================================================================
         * KEY OBSERVATIONS:
         * ====================================================================
         * 
         * WITH MEMORY:
         * ✅ AI remembers name (Alice) and age (28)
         * ✅ Can answer follow-up questions
         * ✅ Maintains conversation context
         * ✅ Feels natural and conversational
         * 
         * WITHOUT MEMORY:
         * ❌ Each message is independent
         * ❌ Can't reference previous information
         * ❌ User must repeat context every time
         * ❌ Feels robotic and disconnected
         * 
         * ====================================================================
         * MEMORY MANAGEMENT BEST PRACTICES:
         * ====================================================================
         * 
         * 1. SIZE MATTERS
         *    - Too small: Loses important context
         *    - Too large: Costs more, may hit token limits
         *    - Typical: 10-20 messages for chat
         * 
         * 2. CLEAR WHEN NEEDED
         *    - New topic: memory.clear()
         *    - New user session
         *    - Context switch
         * 
         * 3. PERSIST FOR PRODUCTION
         *    - Save to database
         *    - Load on user return
         *    - Enable cross-session memory
         * 
         * 4. MONITOR USAGE
         *    - Track memory size
         *    - Watch token consumption
         *    - Alert on limits
         * 
         * ====================================================================
         * WHEN TO USE EACH MEMORY TYPE:
         * ====================================================================
         * 
         * MESSAGE WINDOW (this example):
         * ✅ Simple conversations
         * ✅ Predictable memory usage
         * ✅ Easy to understand
         * 
         * TOKEN WINDOW (see Example03):
         * ✅ Cost-conscious applications
         * ✅ Precise control needed
         * ✅ Variable message lengths
         * 
         * SUMMARY MEMORY (advanced):
         * ✅ Very long conversations
         * ✅ Need to remember old context
         * ✅ Can afford processing time
         */
    }
    
    /**
     * Helper method: Demonstrate memory clearing
     */
    public static void demonstrateMemoryClear() {
        ChatMemory memory = MessageWindowChatMemory.withMaxMessages(10);
        
        // Add some messages
        memory.add(UserMessage.from("Message 1"));
        memory.add(AiMessage.from("Response 1"));
        memory.add(UserMessage.from("Message 2"));
        
        System.out.println("Messages before clear: " + memory.messages().size());
        // Output: 3
        
        // Clear memory
        memory.clear();
        
        System.out.println("Messages after clear: " + memory.messages().size());
        // Output: 0
        
        // Use cases for clearing:
        // - User says "let's start over"
        // - Topic change
        // - New user session
        // - Privacy (forget sensitive info)
    }
}

/*
 * ============================================================================
 * EXERCISE IDEAS:
 * ============================================================================
 * 
 * 1. PERSONAL ASSISTANT
 *    - User shares preferences (favorite food, hobbies)
 *    - Later asks for recommendations
 *    - AI uses memory to personalize
 * 
 * 2. STORY BUILDER
 *    - User builds a story incrementally
 *    - Each turn adds details
 *    - AI maintains consistency using memory
 * 
 * 3. TUTOR BOT
 *    - Explains a topic
 *    - User asks questions
 *    - AI references previous explanations
 * 
 * 4. MEMORY CAPACITY TEST
 *    - Send 15 messages (more than maxMessages=10)
 *    - Verify oldest messages are dropped
 *    - Check what AI still remembers
 * 
 * ============================================================================
 * ADVANCED TOPICS (Later Modules):
 * ============================================================================
 * 
 * - Persistent memory (save/load from database)
 * - Token window memory (by token count, not message count)
 * - Summary memory (summarize old messages to save space)
 * - Multi-user memory (different memory per user)
 * - Hybrid approaches (combine multiple strategies)
 */

