# Module 3: Memory Systems

## 🎯 Learning Goals

By the end of this module, you will:
- Understand different types of memory
- Implement conversation history
- Use message window vs token window memory
- Build stateful conversational agents
- Manage conversation context effectively

## 📚 Theory

### Why Memory?

Without memory, each interaction is isolated:
```
User: "My name is John"
AI: "Nice to meet you!"
User: "What's my name?"
AI: "I don't know your name."  ❌
```

With memory:
```
User: "My name is John"
AI: "Nice to meet you, John!"
User: "What's my name?"
AI: "Your name is John!"  ✅
```

### Types of Memory in LangChain4j

#### 1. **Message Window Memory**
Stores the last N messages.

**Pros**: Simple, predictable
**Cons**: May lose important early context

```
Window size = 3
[msg1, msg2, msg3, msg4, msg5, msg6]
         Kept: [msg4, msg5, msg6]
```

#### 2. **Token Window Memory**
Stores messages up to N tokens.

**Pros**: Precise control, cost-effective
**Cons**: More complex

```
Token limit = 100
Messages kept until total tokens ≤ 100
```

### Memory Architecture

```
User Input
    ↓
Add to Memory
    ↓
Retrieve Context (last N messages/tokens)
    ↓
Send to LLM (context + new message)
    ↓
AI Response
    ↓
Add AI response to Memory
```

### When to Use Each Type

| Use Case | Recommended Memory |
|----------|-------------------|
| **Short conversations** | Message Window (10-20 messages) |
| **Cost-sensitive** | Token Window |
| **Long conversations** | Token Window or Summarization |
| **Simple chatbot** | Message Window |
| **Production app** | Token Window + Persistence |

## 💻 Examples

### Example 1: Basic Chat Memory
**File**: `Example01_BasicChatMemory.java`

Simple conversation with history.

**Concepts**:
- ChatMemory interface
- MessageWindowChatMemory
- Adding user/AI messages
- Retrieving history

### Example 2: AI Service with Memory
**File**: `Example02_AIServiceWithMemory.java`

Combining AI Services with conversation memory.

**Concepts**:
- Stateful AI Services
- Automatic memory management
- Memory injection
- Conversation IDs

### Example 3: Token Window Memory
**File**: `Example03_TokenWindowMemory.java`

Managing conversations by token count.

**Concepts**:
- TokenWindowChatMemory
- Token counting
- Cost optimization
- Context trimming

### Example 4: Persistent Memory
**File**: `Example04_PersistentMemory.java`

Saving and loading conversation history.

**Concepts**:
- Persistent storage
- Session management
- Loading past conversations
- Multi-user support

## 🎓 Key Takeaways

1. **Memory enables context** - Conversations feel natural
2. **Choose the right type** - Message vs Token window
3. **Manage memory size** - Don't exceed model limits
4. **Persist for production** - Save conversation history

## ✅ Exercises

### Exercise 1: Personal Assistant
Build a chatbot that remembers user preferences.

**Requirements**:
- Remember user's name, interests
- Provide personalized responses
- Handle conversation across sessions

### Exercise 2: Interview Bot
Create an AI interviewer that asks follow-up questions.

**Concepts**:
- Keep track of answers
- Ask relevant follow-ups
- Summarize at the end

### Exercise 3: Shopping Assistant
Build an agent that helps with shopping.

**Requirements**:
- Remember items added to cart
- Track budget
- Make recommendations based on conversation

## 📖 Additional Reading

- [LangChain4j Memory Docs](https://docs.langchain4j.dev/tutorials/chat-memory)
- [Managing Context Window](https://platform.openai.com/docs/guides/prompt-engineering)

## ➡️ Next Module

Ready for **Module 4: Tools & Function Calling** to give your agents superpowers!

